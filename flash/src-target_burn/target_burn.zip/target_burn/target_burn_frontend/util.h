/*******************************************************************************
 * File name: util.h
 * Description: Flash Burner
 * Author: Shiva
 * Revision history:
 * 2011/05/23	Create this file.
 * ****************************************************************************/
#ifndef __UTIL__
#define __UTIL__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <getopt.h>

#ifdef __MINGW32__
#include <winsock2.h>
#undef socklen_t
#define socklen_t int
#define sleep(t) _sleep(t * 1000)
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>
#endif

#ifdef __MINGW32__
#define    SEND(SOCKET, DATA, SIZE) send(SOCKET, DATA, SIZE, 0)
#define    RECV(SOCKET, DATA, SIZE) recv(SOCKET, DATA, SIZE, 0)
#else
#define    SEND(SOCKET, DATA, SIZE) write(SOCKET, DATA, SIZE)
#define    RECV(SOCKET, DATA, SIZE) read(SOCKET, DATA, SIZE)
#endif

#define MAX_MULTI_WRITE_PAIR  256

#define MAX_SOCKET_BUF        65536

#define NDS_EDM_SR_EDM_CFG  0x28


/* type define */
typedef unsigned long long      UINT64;
typedef long long               INT64;
typedef unsigned int            UINT32;
typedef int                     INT32;
typedef unsigned short          UINT16;
typedef short                   INT16;
typedef unsigned char           UINT8;
//typedef char                    INT8;


void handle_int(int signo);
void initial_socket(const char *host, unsigned int port);
unsigned char* get_image(FILE* image, unsigned int* size);

#endif

