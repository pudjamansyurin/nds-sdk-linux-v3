#include <sys/time.h>
#ifdef __MINGW32__
#include <winsock2.h>  // for Sleep()
#endif
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "util.h"

#define DEF_CONNECT_HOST	  "127.0.0.1"
#define DEF_CONNECT_PORT	  4444

#ifdef __MINGW32__
extern SOCKET sock;
#else
extern int sock;
#endif
extern int telnet_client_main(void *user_data);
unsigned int telnet_verify_only = 0, telnet_do_verify = 0;
unsigned int telnet_burn_addr = 0, telnet_unlock = 0, telnet_lock = 0, telnet_burn_image_size = 0;
char *telnet_image_filename = NULL;
char *algorithm_bin_filename = NULL;
int nds32_usage(void);
char *nds32_change_filepath(char *ori_filename);
int targetnum = 0;
char target_name[50] = "";

/* Log file descriptor */
FILE *pLogFile;

/* option structure */
static struct option long_option[] = {
	{"help", no_argument, 0, 'h'},
	{"target", required_argument, 0, 'N'},
	{"target", required_argument, 0, 'x'},
	{"lock", no_argument, 0, 'z'},
	{"unlock", no_argument, 0, 'y'},
	{"verify", no_argument, 0, 'v'},
	{"verify-only", no_argument, 0, 'c'},
	{"version", no_argument, 0, 'V'},
	{"erase-all", no_argument, 0, 'u'},
	{"log", required_argument, 0, 'l'},
	{"host", required_argument, 0, 'H'},
	{"port", required_argument, 0, 'p'},
	{"addr", required_argument, 0, 'a'},
	{"base", required_argument, 0, 'b'},
	{"image", required_argument, 0, 'i'},
	{"algorithm-bin", required_argument, 0, 'A'},
	{"telnet", required_argument, 0, 'P'},
	{"core-num", required_argument, 0, 'n'},
	{"target-num", required_argument, 0, 'n'},
	{0, 0, 0, 0}
};

/* main function */
int main(int argc, char **argv)
{
	pLogFile = stdout;

	int c = 0;
	char host[64] = DEF_CONNECT_HOST;			  /* default connecting host */
	unsigned int telnet_port = DEF_CONNECT_PORT;  /* default connecting port */
	unsigned int address = 0;					  /* default write to flash base */
	unsigned int size = 0;						  /* image size */
	FILE *image = NULL;							  /* image to burn */
	char *name = NULL;
	int verify = 0;
	int version_only = 0, verify_only = 0;
	int unlock = 0, lock = 0;

	/* parameter handler */
	while (1) {
		int option_index;
		c = getopt_long(argc, argv, "uvcVhzyl:N:x:H:p:a:b:i:P:A:n:", long_option, &option_index);
		if (c == EOF)
			break;

		switch (c) {
			case 'u':
				break;
			case 'z':
				lock = 1;
				break;
			case 'y':
				unlock = 1;
				break;
			case 'v':
				verify = 1;
				break;
			case 'c':
				verify_only = 1;
				break;
			case 'l':
				name = strdup(optarg); //fopen format  need change /cygdrive/c to c:
				if (strncmp(optarg, "/cygdrive/", 10) == 0) {
					name[0] = optarg[10];
					name[1] = ':';
					name[2] = '\0';
					strcat(name, optarg + 11);
				}
				if ((pLogFile = fopen(name, "w"))== NULL) {
					fprintf (pLogFile, "Error: can't open file %s\n", name);
					fflush(pLogFile);
					exit(1);
				}
				break;
			case 'V':
				version_only = 1;
				break;
			case 'x':
				break;
			case 'H':
				strcpy(host, optarg);
				break;
			case 'P':
				telnet_port = strtol(optarg, NULL, 0);
				break;
			case 'p':
				break;
			case 'a':
				sscanf(optarg,"0x%x", &address);
				break;
			case 'b':
				break;
			case 'A':
				algorithm_bin_filename = strdup(optarg);
				algorithm_bin_filename = nds32_change_filepath(algorithm_bin_filename);
				name = strdup(optarg); //fopen format  need change /cygdrive/c to c:
				if (strncmp(optarg, "/cygdrive/", 10) == 0) {
					name[0] = optarg[10];
					name[1] = ':';
					name[2] = '\0';
					strcat(name, optarg + 11);
				}
				if ((image = fopen(name, "rb"))== NULL) {
					fprintf (pLogFile, "Error: can't open file %s\n", name);
					fflush(pLogFile);
					exit(1);
				}
				fclose (image);
				fprintf(pLogFile, "algorithm_bin_filename: %s\n", name);
				fflush(pLogFile);
				break;
			case 'i':
				telnet_image_filename = strdup(optarg);
				telnet_image_filename = nds32_change_filepath(telnet_image_filename);
				name = strdup(optarg); //fopen format  need change /cygdrive/c to c:
				if (strncmp(optarg, "/cygdrive/", 10) == 0) {
					name[0] = optarg[10];
					name[1] = ':';
					name[2] = '\0';
					strcat(name, optarg + 11);
				}
				if ((image = fopen(name, "rb"))== NULL) {
					fprintf (pLogFile, "Error: can't open file %s\n", name);
					fflush(pLogFile);
					exit(1);
				}
				/* get burn image content */
				get_image (image, &size);
				fclose (image);
				fprintf(pLogFile, "image_filename: %s\n", name);
				fflush(pLogFile);
				break;
			case 'n':
				sscanf(optarg,"%d", &targetnum);
				break;
			case 'N':
				fprintf(pLogFile, "target: %s\n", optarg);
				fflush(pLogFile);
				// process --target duplicate for -x and -N
				if (strncmp(optarg, "ag101p_16mb", 6) == 0) {
				} else if (strncmp(optarg, "ag101", 5) == 0) {
				} else if (strncmp(optarg, "xc5", 3) == 0) {
				} else {
					strcpy(target_name, optarg);
				}
				break;
			case 'h':
			case '?':
			default:
				nds32_usage();
				exit(0);
				break;
		}  /* switch (c)  */
	}  /* while(1)	*/

	fprintf (pLogFile, "NDS32 Burner BUILD_ID: %d\n", BUILD_ID);
	fflush(pLogFile);
	if (version_only) {
		exit(0);
	}
	initial_socket(host, telnet_port);

#ifdef __MINGW32__
	Sleep (200);
#else
	usleep (200000);
#endif

	telnet_burn_addr = address;
	telnet_burn_image_size = size;
	telnet_do_verify = verify;
	telnet_verify_only = verify_only;
	telnet_unlock = unlock;
	telnet_lock = lock;
	telnet_client_main(&sock);

	return 0;
}

/* Help menu */
int nds32_usage(void)
{
	printf( "--host(-H):\t\t\tHost name/ip to connect with ICEman\n");
	printf( "--telnet(-P):\t\t\tTelnet port number to connect with ICEman\n");
	printf( "--addr(-a):\t\t\tFlash target address to write (default to 0x0)\n");
	printf( "--image(-i):\t\t\tImage name to burn\n");
	printf( "--algorithm-bin(-A):\t\tThe algorithm-bin name to burn in target\n");

	printf( "--log(-l):\t\t\tThe log file to store output message (default to stdout)\n");
	printf( "--verify(-v):\t\t\tVerify after flash burning\n");
	printf( "--verify-only(-c):\t\tUse image file to verify content of ROM, no burn\n");
	printf( "--version(-V):\t\t\tShow flash burning version\n");
	printf( "--unlock(-y):\t\t\tUnlock flash before burning\n");
    printf( "--lock(-z):\t\t\tLock flash after burning\n");
	printf( "--help(-h):\t\t\tThe usage for NDS32 Burner\n");
	printf( "--core-num(-n):\t\t\tSelect Target number\n");
	printf( "--target-num(-n):\t\tSelect Target number\n");
	printf( "--target(-N):\t\t\tSelect Target name\n");
	return 0;
}

char *nds32_change_filepath(char *ori_filename)
{
	unsigned int filename_length, i;
	char *cur_str, *resolved_path = NULL, *new_filename = NULL;

	if (ori_filename == NULL)
		return NULL;

	filename_length = strlen(ori_filename);
	resolved_path = (char *)malloc(filename_length + 512);
	if (resolved_path == NULL)
		return NULL;

   //_fullpath cannot process /cygdrive path,so skip
   //_fullpath issue: cannot process on windows path: ../../d/test.bin(/cygdrive/d/test.bin)
	if (strncmp(ori_filename, "/cygdrive/", 10) != 0) {
#ifdef __MINGW32__
		if (_fullpath(resolved_path, ori_filename, filename_length + 512) == NULL ) {
			fprintf(pLogFile, "Error : file %s is not exist\n", ori_filename);
			exit(1);
		}
#else
		if (realpath(ori_filename, resolved_path) == NULL) {
			fprintf(pLogFile, "Error : file %s is not exist\n", ori_filename);
			exit(1);
		}
#endif
	} else {
		resolved_path = strdup(ori_filename);
	}

	free(ori_filename);
	//fprintf(pLogFile, "resolved_file_path: %s \n", resolved_path);
	
	filename_length = strlen(resolved_path);
	new_filename = (char *)malloc(filename_length + 128);
	if (new_filename == NULL)
		return NULL;
	cur_str = new_filename;
	
	for (i = 0; i < filename_length; i++) {
		if (resolved_path[i] == 0x5c) {  //  0x5c => '\'
			*cur_str++ = '/';
		} else if (resolved_path[i] == ' ') {
			*cur_str++ = 0x5c;
			*cur_str++ = ' ';
		} else {
			*cur_str++ = resolved_path[i];
		}
	}
	*cur_str++ = 0;
	free(resolved_path);

	//fprintf(pLogFile, "new_filename: %s \n", new_filename); 
	return new_filename;
}
