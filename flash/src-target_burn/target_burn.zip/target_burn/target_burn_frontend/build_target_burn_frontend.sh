#!/bin/sh
# This script is used to build NDS32 target_burn_frontend for Linux and Windows platform.

BASEDIR=$(dirname "$0")
echo "$BASEDIR"
cd $BASEDIR

for ARG in "$@"; do
	case "$ARG" in
		--bin=*)
			ARG_PATH=${ARG#*=}
			;;
	esac
done
	
export PATH=/home/users/sqa/mingw/bin:$PATH

# Remove all executable file
rm -f target_burn_frontend target_burn_frontend.exe

# For Windows platform
rm -f *.o
rm -f ./telnet/*.o
if type i386-mingw32-gcc 2> /dev/null; then
    export PATH=/home/users/sqa/mingw/bin:$PATH
    make --makefile=Makefile_target_burn_frontend_win clean
    make --makefile=Makefile_target_burn_frontend_win
    i386-mingw32-strip target_burn_frontend.exe
fi

# For Linux platform
rm -f *.o
rm -f ./telnet/*.o
make --makefile=Makefile_target_burn_frontend_linux clean
make --makefile=Makefile_target_burn_frontend_linux
strip target_burn_frontend

cd -
