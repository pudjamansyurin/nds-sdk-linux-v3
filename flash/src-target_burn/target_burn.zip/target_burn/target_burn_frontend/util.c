/*******************************************************************************
 * File name: util.cpp
 * Description: Intel Flash burner
 * Author: Shiva
 * Revision history:
 * 2011/05/23	Create this file.
 * 2012/05/24	Add comments - Kai
 * ****************************************************************************/

#include "util.h"
#include <stdio.h>

#ifdef __MINGW32__
SOCKET sock;
#else
int sock;
#endif

extern FILE *pLogFile;					/* log file */

/* Close connection with ICEman */
void close_connection (void)
{
	char send_data[2];
	int retval __attribute__((unused));

	send_data[0] = 4; // Termination command code
	retval = SEND(sock, send_data, 1);

	// free socket resource
#ifdef __MINGW32__
	closesocket (sock);
	do {
		WSACleanup ();
	} while (WSAGetLastError () != WSANOTINITIALISED);
#else
	close (sock);
#endif
}

/* Need send terminate to ICEman before quit Burner */
void terminate(void)
{
	close_connection ();
}

/* SIGINT handling function */
void handle_int(int signo)
{
	terminate();
	fprintf(pLogFile, "\n!! burn not done yet !!\n");
	fflush(pLogFile);
	exit(0);
}

/* Prepare socket communication */
void initial_socket(const char *host, unsigned int port)
{
	struct sockaddr_in server_addr;

#ifdef __MINGW32__
	WSADATA wsadata;
	if (WSAStartup(MAKEWORD(1,1), &wsadata) == SOCKET_ERROR) {
		fprintf(pLogFile, "Error creating socket.");
		fflush(pLogFile);
		fflush(stdout);
	}
#endif

#ifdef __MINGW32__
	if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
#else
	if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1)
#endif
	{
		fprintf(pLogFile, "can't create socket\n");
		fflush(pLogFile);
		exit(1);
	}
	server_addr.sin_family = PF_INET;
	server_addr.sin_port = htons(port);
#ifdef __MINGW32__
	server_addr.sin_addr.s_addr = inet_addr(host);
#else
	inet_aton(host, &server_addr.sin_addr);
#endif
	memset(&(server_addr.sin_zero),0,8);
	if (connect(sock, (struct sockaddr *)&server_addr,
					sizeof(struct sockaddr)) == -1) {
		fprintf(pLogFile, "connecting fail !!\n");
		fflush(pLogFile);
		exit(1);
	}

	// Set RCV/SND Timeout
	struct timeval timeout;

#ifdef __MINGW32__
	timeout.tv_sec = 30000;  // 30s
	timeout.tv_usec = 0;
#else
	timeout.tv_sec = 30;  // 30s
	timeout.tv_usec = 0;
#endif

	if ( setsockopt( sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout)) < 0 ) {
		fprintf(pLogFile, "setsockopt SO_RCVTIMEO fail !!\n");
		fflush(pLogFile);
		exit(1);
	}

	if ( setsockopt( sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(timeout)) < 0 ) {
		fprintf(pLogFile, "setsockopt SO_SNDTIMEO fail !!\n");
		fflush(pLogFile);
		exit(1);
	}

}

/* Read image binary data */
unsigned char* get_image(FILE* image, unsigned int* size)
{
	unsigned char* flash;
	unsigned int word_aligned_size = 0;
	int retval __attribute__((unused));
	if (image == NULL) {
		fprintf (pLogFile, "Error: Burn image have to specify.\n");
		fflush(pLogFile);
		exit(1);
	}

	fseek(image, 0L, SEEK_END);
	(*size) = (ftell(image));
	fseek(image, 0L, SEEK_SET);

	//allocate word-aligned memory size
	word_aligned_size = (((*size) + 3) / 4) * 4;
   
	if ((flash = (UINT8*)malloc(word_aligned_size * (sizeof(UINT8)))) == NULL) {
		fprintf(pLogFile, "Error: can't allocate memory (%d bytes) for flash file\n", word_aligned_size);
		fflush(pLogFile);
		return 0;
	}
	retval = fread(flash, (*size), 1, image);
	return flash;
}
