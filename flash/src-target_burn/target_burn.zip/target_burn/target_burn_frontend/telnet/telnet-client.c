/*
 * Sean Middleditch
 * sean@sourcemud.org
 *
 * The author or authors of this code dedicate any and all copyright interest
 * in this code to the public domain. We make this dedication for the benefit
 * of the public at large and to the detriment of our heirs and successors. We
 * intend this dedication to be an overt act of relinquishment in perpetuity of
 * all present and future rights to this code under copyright law. 
 */

#if !defined(_POSIX_SOURCE)
#define _POSIX_SOURCE
#endif
#if !defined(_BSD_SOURCE)
#define _BSD_SOURCE
#endif

#include <sys/types.h>
#include "../util.h"

#ifdef __MINGW32__
#include <winsock2.h>
#undef socklen_t
#define socklen_t int
#define Sleep(t) _sleep(t)
//#include <conio.h>
SOCKET telnet_sock;
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <poll.h>
#include <termios.h>

#define Sleep(t) usleep(t * 1000)
int telnet_sock;
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <stdarg.h>

#include <ctype.h>
#include <unistd.h>

#ifdef HAVE_ZLIB
#include "zlib.h"
#endif

#include "libtelnet.h"

#define TELNET_CMD_INIT	        "init"
#define TELNET_CMD_RESET_HALT   "reset halt" //reset and halt all targets and cores
#define TELNET_CMD_HALT	        "halt"       //halt current target
#define TELNET_CMD_RESET        "reset"
#define TELNET_CMD_RESUME       "resume"
#define TELNET_CMD_TARGETS      "targets"
#define TELNET_CMD_TARGETS_OK   "targets done"
#define TELNET_CMD_TARGETS_FAIL "is unknown, try one of"
#define TELNET_CMD_TARGET_NUM   "nds configure targetburn_targetnum"
#define TELNET_CMD_MDW          "mdw"
#define TELNET_CMD_QUERY        "nds query capability"
#define TELNET_FLASH_SIZE       "flash total size:"
#define TELNET_CMD_ALGORITHM    "nds configure algorithm_bin"
//#define NDSSPI_ALGBIN_MAME    "./algorithm.bin"
#define NDSSPI_IMAGE_FAIL       "couldn't open"
#define NDSSPI_RATE	            "bytes from file"
#define NDSSPI_VERIFY_OK        "contents match"
#define NDSSPI_VERIFY           "contents"

#define NDSSPI_WRITESIZE        "WRITESIZE"
#define NDSSPI_DOT              "SPI_DOT"
#define NDSSPI_WRITE_8K	        "SPI_WRITE_8K"
#define NDSSPI_READ_8K          "SPI_READ_8K"
#define NDSSPI_READ_START       "SPI_READ_START"
#define NDSSPI_WRITE_START      "SPI_WRITE_START"
#define NDSSPI_READ_FINISH      "SPI_READ_FINISH"
#define NDSSPI_WRITE_FINISH	    "SPI_WRITE_FINISH"
#define NDSSPI_INIT_FAIL        "SPI_INIT_FAIL"
#define NDSSPI_SEND_LOCK        "set protection for sectors"
#define NDSSPI_SEND_UNLOCK      "cleared protection for sectors"
#define NDSSPI_UNLOCK_FAIL      "unlock flash error"
#define NDSSPI_LOCK_FAIL        "lock flash error"

#define TELNET_CMD_QUERY_DONE   "targetburn:"
#define TELNET_TARGET_BURN      "targetburn:1"
#define TELNET_CMD_PROBE        "flash probe 0"
#define TELNET_CMD_LOCK         "flash protect 0 0 last on"
#define TELNET_CMD_UNLOCK       "flash protect 0 0 last off"
#define TELNET_CMD_WRITE        "flash write_bank"					// #flash write_bank 0 ./ae250.bin 0
#define TELNET_CMD_VERIFY       "flash verify_bank"					// #flash verify_bank 0 ./ae250.bin 0

#define TELNET_CMD_BUS          "nds mem_access bus"
#define NDSSPI_BUS_OK           "change memory access channel pass"
#define TELNET_CMD_CPU          "nds mem_access cpu"
#define NDSSPI_CPU_OK           "change memory access channel pass"

#define NDSSPI_READ_SMU	        "mdw 0xf0100000"
#define NDSSPI_READ_SMU_16      "mdw 0xf01000"
#define NDSSPI_WRITE_LOOP_V3    "mww 0x0 0x00d5"
#define NDSSPI_WRITE_LOOP_V5    "mww 0x0 0xa001"
#define NDSSPI_SMU_DONE	        "0xf0100000:"
#define NDSSPI_SMU_DONE_16      "0xf01000:"
#define NDSSPI_ae250_SMU        "0xf0100000: 41452500"
#define NDSSPI_ae350_SMU        "0xf0100000: 41453500"
#define NDSSPI_ae300_SMU        "0xf0100000: 41453002"
#define NDSSPI_ae210_SMU        "0xf0100000: 41452141"
#define NDSSPI_ae100_SMU        "0xf01000: 41451000"
#define NDSSPI_ae210_SMU_16     "0xf01000: 41452110"

#define NDSSPI_IVB_AE100        "mww 0xf01024 0x800000"
#define NDSSPI_IVB_AE300        "mww 0xf0100050 0x80000000"

#define NDSSPI_READ_IVB_AE100   "mdw 0xf01024"
#define NDSSPI_IVB_AE100_DONE   "0xf01024: 800000"

#define NDSSPI_READ_IVB_AE300   "mdw 0xf0100050"
#define NDSSPI_IVB_AE300_DONE   "0xf0100050: 80000000"

#define READ_SMU_FAIL           "not halted"
#define ERROR_MSG               "E "
#define ERROR_CODE              "EC"

struct entry {
	int err_c;
	char *err_str;
};
struct entry err_table[] = {
	{0, "tx_size = 0"},
	{1, "sector_1st > sector_last"},
	{2, "SPIROM_CMD_RDID, read ID fail"},
	{3, "SPIROM_CMD_WREN, enable write fail"},
	{4, "Flash block locked"},
	{5, "SPIROM_CMD_ERASE, rom erase fail"},
	{6, "erase is still in progress"},
	{7, "SPIROM_CMD_RDSCUR, erase fail"},
	{8, "addr is NOT page-align"},
	{9, "write enable is not set"},
	{10, "SPIROM_CMD_PROGRAM, program fail"},
	{11, "program is still in progress"},
	{12, "SPIROM_CMD_RDSCUR, program fail"},
	{13, "SPIROM_CMD_READ, read fail"},
	{14, "lock is still in progress"},
	{15, "SPIROM_CMD_RDBLOCK, Lock fail"},
	{16, "unlock is still in progress"},
	{17, "SPIROM_CMD_RDBLOCK, ULock fail"},
	{18, "no match SMU_SYSID"},
	{19, "micron_check, ID error"},
	{20, "micron_wait_program_done, program fail"},
	{-1, NULL}
};

extern char *telnet_image_filename, *algorithm_bin_filename;
extern FILE *pLogFile;
extern unsigned int telnet_do_verify, telnet_verify_only, telnet_unlock, telnet_burn_addr, telnet_burn_image_size, telnet_lock;
extern int targetnum;
extern char target_name[50];

unsigned int dis_printf_out = 0;
unsigned int cur_recv_length = 0;

static char recv_data[512];
static char send_data[512];
static telnet_t *telnet;
static int do_echo;

static const telnet_telopt_t telopts[] = {
	{ TELNET_TELOPT_ECHO,		TELNET_WONT, TELNET_DO	 },
	{ TELNET_TELOPT_TTYPE,		TELNET_WILL, TELNET_DONT },
	{ TELNET_TELOPT_COMPRESS2,	TELNET_WONT, TELNET_DO	 },
	{ TELNET_TELOPT_MSSP,		TELNET_WONT, TELNET_DO	 },
	{ -1, 0, 0 }
};

#if 0
static void _input(char *buffer, int size) {
	static char crlf[] = { '\r', '\n' };
	int i;

	for (i = 0; i != size; ++i) {
		/* if we got a CR or LF, replace with CRLF
		 * NOTE that usually you'd get a CR in UNIX, but in raw
		 * mode we get LF instead (not sure why)
		 */
		if (buffer[i] == '\r' || buffer[i] == '\n') {
			if (do_echo)
				printf("\r\n");
			telnet_send(telnet, crlf, 2);
		} else {
			if (do_echo)
				putchar(buffer[i]);
			telnet_send(telnet, buffer + i, 1);
		}
	}
	fflush(pLogFile);
}
#endif

#ifdef __MINGW32__
static void _send(SOCKET sock, const char *buffer, size_t size) {
#else
static void _send(int sock, const char *buffer, size_t size) {
#endif
	int rs;

	/* send data */
	while (size > 0) {
		if ((rs = SEND(sock, buffer, size)) == -1) {
			fprintf(pLogFile, "send() failed: %s\n", strerror(errno));
			exit(1);
		} else if (rs == 0) {
			fprintf(pLogFile, "send() unexpectedly returned 0\n");
			exit(1);
		}

		/* update pointer and size to see if we've got more to send */
		buffer += rs;
		size -= rs;
	}
}

static void _event_handler(telnet_t *telnet, telnet_event_t *ev,
		void *user_data) {
#ifdef __MINGW32__
SOCKET sock = *(SOCKET*)user_data;
#else
int sock = *(int*)user_data;
#endif

	switch (ev->type) {
	/* data received */
	case TELNET_EV_DATA:
		memcpy(recv_data, ev->data.buffer, ev->data.size);
		recv_data[ev->data.size] = 0; // string end
		//fprintf(pLogFile, "\nev->size=%d, %s\n",ev->data.size, &recv_data[0]);
		if (dis_printf_out == 0) {
			if (ev->data.size && fwrite(ev->data.buffer, 1, ev->data.size, stdout) != ev->data.size) {
				fprintf(pLogFile, "ERROR: Could not write complete buffer to stdout");
			}
			fflush(pLogFile);
		}
		break;
	/* data must be sent */
	case TELNET_EV_SEND:
		_send(sock, ev->data.buffer, ev->data.size);
		break;
	/* request to enable remote feature (or receipt) */
	case TELNET_EV_WILL:
		/* we'll agree to turn off our echo if server wants us to stop */
		if (ev->neg.telopt == TELNET_TELOPT_ECHO)
			do_echo = 0;
		break;
	/* notification of disabling remote feature (or receipt) */
	case TELNET_EV_WONT:
		if (ev->neg.telopt == TELNET_TELOPT_ECHO)
			do_echo = 1;
		break;
	/* request to enable local feature (or receipt) */
	case TELNET_EV_DO:
		break;
	/* demand to disable local feature (or receipt) */
	case TELNET_EV_DONT:
		break;
	/* respond to TTYPE commands */
	case TELNET_EV_TTYPE:
		/* respond with our terminal type, if requested */
		if (ev->ttype.cmd == TELNET_TTYPE_SEND) {
			telnet_ttype_is(telnet, getenv("TERM"));
		}
		break;
	/* respond to particular subnegotiations */
	case TELNET_EV_SUBNEGOTIATION:
		break;
	/* error */
	case TELNET_EV_ERROR:
		fprintf(pLogFile, "ERROR: %s\n", ev->error.msg);
		exit(1);
	default:
		/* ignore */
		break;
	}
}

int telnet_client_recv(char *compare_str, unsigned int timeout_cnt) {
	char buffer[512];
	unsigned int cur_cnt = 0;
	int rs = 0, pre_rs = -1, tmp_rs = 0;
	char *curr_str;

	while(1) {
		Sleep(10);
		rs += RECV(telnet_sock, &buffer[rs], sizeof(buffer));

		//fprintf(pLogFile, "\nrs=%d, buffer:%s -end\n",rs, buffer);
		if (rs == -1) {
			fprintf(pLogFile, "\nrs=%d, buffer:%s -end\n",rs, buffer);
			return -1;
		}
		//check receive new buffer
		if (rs <= pre_rs) {
			fprintf(pLogFile, "\nno new buffer, rs=%d, buffer:%s -end\n",rs, buffer);
			return -1;
		}

		if ( rs >= strlen(compare_str) ) {
			telnet_recv(telnet, buffer, rs);
			//cur_recv_length for compare many strings ex:probe function need match totalsize related string and probe success string
			cur_recv_length = rs;
			//keep rs to process expected string no complete send at one transmission
			tmp_rs = rs;
			curr_str = (char *)&recv_data[0];
			//fprintf(pLogFile, "\nrs=%d, %s -end\n",rs, curr_str);
			while(tmp_rs) {
				if (strncmp(curr_str, compare_str, strlen(compare_str)) == 0) {
					//memset(recv_data, 0, strlen(recv_data));
					return 0;
				}
				curr_str ++;
				tmp_rs --;
			}
			cur_cnt ++;
			if (cur_cnt > timeout_cnt)
				break;
		}
		pre_rs = rs;
	}

	return -1;
}

int telnet_query(void) {
	char *curr_str;
	unsigned int read_finish = 0, recv_length;

	sprintf(send_data, "%s\r\n", TELNET_CMD_QUERY);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(TELNET_CMD_QUERY, 0);
		
	while(read_finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			if (strncmp(curr_str, TELNET_CMD_QUERY_DONE, strlen(TELNET_CMD_QUERY_DONE)) == 0) {
				read_finish = 1;
				break;
			}
			curr_str ++;
			recv_length --;
		}
		if (read_finish == 0)
			telnet_client_recv(TELNET_CMD_QUERY_DONE, 0);
	}
	if (strncmp(curr_str, TELNET_TARGET_BURN, strlen(TELNET_TARGET_BURN)) == 0) {
		return 0;
	}
	return -1;
}

int check_platform(void) {
	//read SMU ID
	unsigned int flag = 0;
	char *curr_str;
	unsigned int read_finish = 0, recv_length;

	sprintf(send_data, "%s\r\n", NDSSPI_READ_SMU);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(NDSSPI_READ_SMU, 0);

	while(read_finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			if (strncmp(curr_str, NDSSPI_SMU_DONE, strlen(NDSSPI_SMU_DONE)) == 0) {
				read_finish = 1;
				break;
			} else if (strncmp(curr_str, READ_SMU_FAIL, strlen(READ_SMU_FAIL)) == 0) {
				fprintf(pLogFile, "\ntarget was not halted\n");
				fflush(pLogFile);
				return -1;
			}
			curr_str ++;
			recv_length --;
		}
		if (read_finish == 0)
			telnet_client_recv(NDSSPI_SMU_DONE, 0);
	}
	if (strncmp(curr_str, NDSSPI_ae250_SMU, strlen(NDSSPI_ae250_SMU)) == 0)
		flag = 250;
	else if (strncmp(curr_str, NDSSPI_ae350_SMU, strlen(NDSSPI_ae350_SMU)) == 0)
		flag = 350;
	else if (strncmp(curr_str, NDSSPI_ae300_SMU, strlen(NDSSPI_ae300_SMU)) == 0)
		flag = 300;
	else if (strncmp(curr_str, NDSSPI_ae210_SMU, strlen(NDSSPI_ae210_SMU)) == 0)
		flag = 210;

	if (flag != 0)
		return flag;

	sprintf(send_data, "%s\r\n", NDSSPI_READ_SMU_16);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(NDSSPI_READ_SMU_16, 0);

	while(read_finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			if (strncmp(curr_str, NDSSPI_SMU_DONE_16, strlen(NDSSPI_SMU_DONE_16)) == 0) {
				read_finish = 1;
				break;
			} else if (strncmp(curr_str, READ_SMU_FAIL, strlen(READ_SMU_FAIL)) == 0) {
				fprintf(pLogFile, "\ntarget was not halted\n");
				fflush(pLogFile);
				return -1;
			}
			curr_str ++;
			recv_length --;
		}
		if (read_finish == 0)
			telnet_client_recv(NDSSPI_SMU_DONE_16, 0);
	}
	if (strncmp(curr_str, NDSSPI_ae100_SMU, strlen(NDSSPI_ae100_SMU)) == 0)
		flag = 100;
	else if (strncmp(curr_str, NDSSPI_ae210_SMU_16, strlen(NDSSPI_ae210_SMU_16)) == 0)
		flag = 21016;

	return flag;
}

void find_err_msg(char *rec_str) {
	unsigned int num = strtoul(rec_str + strlen(ERROR_CODE), NULL, 10);
	if (num == err_table[num].err_c) {
		fprintf(pLogFile, "Error Code: %d, Error MSG: %s", num, err_table[num].err_str);
		fflush(pLogFile);
	} else {
		int i = 0;
		while (err_table[i].err_c >= 0) {
			if (err_table[i].err_c == num) {
				fprintf(pLogFile, "Error Code: %d, Error MSG: %s", num, err_table[i].err_str);
				fflush(pLogFile);
				break;
			}
			i++;
		}
		if (err_table[i].err_c == -1) {
			fprintf(pLogFile, "Error Code: %d, No match any Error Message", num);
			fflush(pLogFile);
		}
	}
}

int flash_probe() {
	char *curr_str, *p, *end;
	unsigned int finish = 0, recv_length;

	dis_printf_out = 1;
	sprintf(send_data, "%s\r\n", TELNET_CMD_PROBE);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(send_data, 0);

	while(finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;
		while(recv_length) {
			if (strncmp(curr_str, TELNET_FLASH_SIZE, strlen(TELNET_FLASH_SIZE)) == 0) {
				p = strtok(curr_str, ":");
				p = strtok(NULL, ":");
				unsigned int ret = strtoul(p, &end, 16);
				fprintf(pLogFile, "NDSSPI_DEV_TOTALSIZE(from target burn): %d\n", ret);
				fflush(pLogFile);
				//fprintf(pLogFile, "offset(-addr):%d  Image size:%d flash size(define on target burn:NDSSPI_DEV_TOTALSIZE):%d\n", telnet_burn_addr, telnet_burn_image_size, ret);
				//check addr , image size or addr + image size > flash size
				if (telnet_burn_addr > ret) {
					fprintf(pLogFile, "offset(-addr):%d > flash size(define on target burn:NDSSPI_DEV_TOTALSIZE):%d\n", telnet_burn_addr, ret);
					fflush(pLogFile);
					return -1;
				}
				if (telnet_burn_image_size > ret) {
					fprintf(pLogFile, "Image size:%d > flash size(define on target burn:NDSSPI_DEV_TOTALSIZE):%d\n", telnet_burn_image_size, ret);
					fflush(pLogFile);
					return -1;
				}
				if ((telnet_burn_addr + telnet_burn_image_size) > ret) {
					fprintf(pLogFile, "(offset(-addr):%d + Image size:%d) > flash size(define on target burn:NDSSPI_DEV_TOTALSIZE):%d\n", telnet_burn_addr, telnet_burn_image_size, ret);
					fflush(pLogFile);
					return -1;
				}
			}
			if (strncmp(curr_str, "error", strlen("error")) == 0) {
				fprintf(pLogFile, "\n%s\n", curr_str);
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, NDSSPI_INIT_FAIL, strlen(NDSSPI_INIT_FAIL)) == 0) {
				fprintf(pLogFile, "openocd ndsspi_algorithm_apis_init funtion failed\n");
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, "out of bounds", strlen("out of bounds")) == 0) {
				fprintf(pLogFile, "flash bank is out of bounds\n");
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, "probe success", strlen("probe success")) == 0) {
				finish = 1;
				dis_printf_out = 0;
				return 0;
			}
			if (strncmp(curr_str, ERROR_MSG, strlen(ERROR_MSG)) == 0) {
				fprintf(pLogFile, "\nError MSG: %s\n", curr_str + strlen(ERROR_MSG));
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, ERROR_CODE, strlen(ERROR_CODE)) == 0) {
				find_err_msg(curr_str);
				return -1;
			}
			curr_str ++;
			recv_length --;
		}
		telnet_client_recv(NDSSPI_DOT, 0);
	}
	return 0;
}

int telnet_verify(void) {
	char *curr_str;
	unsigned int telnet_verify_addr = telnet_burn_addr;
	unsigned int read_finish = 0, recv_length, catch_read = 0;

	sprintf(send_data, "%s 0 %s %d\r\n", TELNET_CMD_VERIFY, telnet_image_filename, telnet_verify_addr);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(NDSSPI_READ_START, 0);

	fprintf(pLogFile, "\nverifying\n");
	fflush(pLogFile);
	dis_printf_out = 1;
	while(read_finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			if ((strncmp(curr_str, NDSSPI_DOT, strlen(NDSSPI_DOT)) == 0) || (strncmp(curr_str, NDSSPI_READ_8K, strlen(NDSSPI_READ_8K)) == 0)) {
				fprintf(pLogFile, ".");
				fflush(pLogFile);
			}
			if (strncmp(curr_str, NDSSPI_READ_FINISH, strlen(NDSSPI_READ_FINISH)) == 0) {
				catch_read = 1;
			}
			if (catch_read == 1 && strncmp(curr_str, NDSSPI_RATE, strlen(NDSSPI_RATE)) == 0) {
				fprintf(pLogFile, "\n%s", recv_data);
				fflush(pLogFile);
			}
			if (strncmp(curr_str, NDSSPI_VERIFY, strlen(NDSSPI_VERIFY)) == 0) {
				//fprintf(pLogFile, "\n%s", recv_data);
				//fflush(pLogFile);
				read_finish = 1;
				dis_printf_out = 0;
				if (strncmp(curr_str, NDSSPI_VERIFY_OK, strlen(NDSSPI_VERIFY_OK)) == 0) {
					fprintf(pLogFile, "\nVerify success.\n");
					return 0;
				}
				else {
					fprintf(pLogFile, "\nVerify fail !!!\n");
					return -1;
				}
			}
			if (strncmp(curr_str, "error", strlen("error")) == 0) {
				fprintf(pLogFile, "\n%s\n", curr_str);
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, ERROR_MSG, strlen(ERROR_MSG)) == 0) {
				fprintf(pLogFile, "\nError MSG: %s\n", curr_str + strlen(ERROR_MSG));
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, ERROR_CODE, strlen(ERROR_CODE)) == 0) {
				find_err_msg(curr_str);
				return -1;
			}
			curr_str ++;
			recv_length --;
		}
		telnet_client_recv(NDSSPI_DOT, 0);
	}
	return 0;
}

int telnet_burning(void) {
	char *curr_str;
	unsigned int FlashAddr = telnet_burn_addr;
	unsigned int write_finish = 0, recv_length;

	fprintf(pLogFile, "erase from address = 0x%x\n", FlashAddr);
	fprintf(pLogFile, "burn flash from 0x%x\n", FlashAddr);
	//fprintf(pLogFile, "burn flash from 0x%x to 0x1234\n", FlashAddr);
	fflush(pLogFile);
	dis_printf_out = 1;
	sprintf(send_data, "%s 0 %s %d\r\n", TELNET_CMD_WRITE, telnet_image_filename, FlashAddr);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(NDSSPI_WRITE_START, 0);

	/*if (telnet_client_recv(NDSSPI_IMAGE_FAIL, 3) == 0) {
		fprintf(pLogFile, "couldn't open %s, please check the path of image file can access from ICEman folder\n", telnet_image_filename);
		fflush(pLogFile);
		return -1;
	}*/

	//telnet_client_recv(NDSSPI_WRITE_START, 10);

	//fprintf(pLogFile, "\nburn\n");
	//fflush(pLogFile);
	//fprintf(pLogFile, ".");
	//fflush(pLogFile);

	while(write_finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			//fprintf(pLogFile, "recv_length:%d %s", recv_length, curr_str);
			//fflush(pLogFile);
			if (strncmp(curr_str, NDSSPI_WRITESIZE, strlen(NDSSPI_WRITESIZE)) == 0) {
				fprintf(pLogFile, "\n%s\n", curr_str);
				fflush(pLogFile);
			}
			if ((strncmp(curr_str, NDSSPI_DOT, strlen(NDSSPI_DOT)) == 0) || (strncmp(curr_str, NDSSPI_WRITE_8K, strlen(NDSSPI_WRITE_8K)) == 0)) {
				fprintf(pLogFile, ".");
				fflush(pLogFile);
			}
			if (strncmp(curr_str, "error", strlen("error")) == 0) {
				fprintf(pLogFile, "\n%s\n", curr_str);
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, ERROR_MSG, strlen(ERROR_MSG)) == 0) {
				fprintf(pLogFile, "\nError MSG: %s\n", curr_str + strlen(ERROR_MSG));
				fflush(pLogFile);
				return -1;
			}
			if (strncmp(curr_str, ERROR_CODE, strlen(ERROR_CODE)) == 0) {
				find_err_msg(curr_str);
				return -1;
			}
			if (strncmp(curr_str, NDSSPI_WRITE_FINISH, strlen(NDSSPI_WRITE_FINISH)) == 0) {
				write_finish = 1;
				dis_printf_out = 0;
				fprintf(pLogFile, "\n%s\n", recv_data);
				fflush(pLogFile);
				return 0;
			}
			curr_str ++;
			recv_length --;
		}
		telnet_client_recv(NDSSPI_DOT, 0);
	}
	return 0;
}

int telnet_sendlock(int msg) {
	char *curr_str;
	unsigned int finish = 0, recv_length;

	dis_printf_out = 1;
	if (msg == 0)
		sprintf(send_data, "%s\r\n", TELNET_CMD_UNLOCK);
	else if(msg == 1)
		sprintf(send_data, "%s\r\n", TELNET_CMD_LOCK);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(send_data, 0);

	while(finish == 0) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			if (msg == 0) {
				if (strncmp(curr_str, NDSSPI_UNLOCK_FAIL, strlen(NDSSPI_UNLOCK_FAIL)) == 0) {
					fprintf(pLogFile, "\nunlock flash failed\n");
					fflush(pLogFile);
					return -1;
				}
				if (msg == 0 && strncmp(curr_str, NDSSPI_SEND_UNLOCK, strlen(NDSSPI_SEND_UNLOCK)) == 0) {
					finish = 1;
					dis_printf_out = 0;
					fprintf(pLogFile, "\n%s\n",recv_data);
					fflush(pLogFile);
					return 0;
				}
				if (strncmp(curr_str, "error", strlen("error")) == 0) {
					fprintf(pLogFile, "\n%s\n", curr_str);
					fflush(pLogFile);
					return -1;
				}
				if (strncmp(curr_str, ERROR_MSG, strlen(ERROR_MSG)) == 0) {
					fprintf(pLogFile, "\nError MSG: %s\n", curr_str + strlen(ERROR_MSG));
					fflush(pLogFile);
					return -1;
				}
				if (strncmp(curr_str, ERROR_CODE, strlen(ERROR_CODE)) == 0) {
					find_err_msg(curr_str);
					return -1;
				}
			} else if (msg == 1) {
				if (strncmp(curr_str, NDSSPI_LOCK_FAIL, strlen(NDSSPI_LOCK_FAIL)) == 0) {
					fprintf(pLogFile, "\nlock flash failed\n");
					fflush(pLogFile);
					return -1;
				}
				if (strncmp(curr_str, NDSSPI_SEND_LOCK, strlen(NDSSPI_SEND_LOCK)) == 0) {
					finish = 1;
					dis_printf_out = 0;
					fprintf(pLogFile, "\n%s\n",recv_data);
					fflush(pLogFile);
					return 0;
				}
				if (strncmp(curr_str, "error", strlen("error")) == 0) {
					fprintf(pLogFile, "\n%s\n", curr_str);
					fflush(pLogFile);
					return -1;
				}
				if (strncmp(curr_str, ERROR_MSG, strlen(ERROR_MSG)) == 0) {
					fprintf(pLogFile, "\nError MSG: %s\n", curr_str + strlen(ERROR_MSG));
					fflush(pLogFile);
					return -1;
				}
				if (strncmp(curr_str, ERROR_CODE, strlen(ERROR_CODE)) == 0) {
					find_err_msg(curr_str);
					return -1;
				}
			} else {
					fprintf(pLogFile, "\nno this command\n");
					fflush(pLogFile);
					return -1;
			}
			curr_str ++;
			recv_length --;
		}
		telnet_client_recv(NDSSPI_DOT, 0);
	}
	return 0;
}

int telnet_start_burn(void) {
	/* handle signal */
	signal(SIGTERM, handle_int);
	signal(SIGINT, handle_int);
#ifndef __MINGW32__
	signal(SIGKILL, handle_int);
#endif

	/* verify only */
	if (telnet_verify_only) {
		telnet_verify();
		return 0;
	}

	/* do flash probe(call openocd apis_init function)*/
	if (flash_probe() != 0) {
		return -1;
	}

	/* send unlock flash but do unlock after target_burn bin init function */
	if (telnet_unlock) {
		if (telnet_sendlock(0) == 0) {
			fprintf(pLogFile, "\nunlock flash\n");
		}
		else {
			return -1;
		}
	}

	/* program */
	if (telnet_burning() == 0) {
		fprintf(pLogFile, "\nburn finish.\n");
	}
	else {
		fprintf(pLogFile, "\nburn fail !!!\n");
		fflush(pLogFile);
		return -1;
	}

	/* verify */
	if (telnet_do_verify) {
		if (telnet_verify() == 0) {
			fprintf(pLogFile, "Flash burning done.\n");
		}
		else {
			fprintf(pLogFile, "Please reburn again.\n");
		}
		fflush(pLogFile);
	}

	/* send lock flash but do lock after target_burn bin tx function */
	if (telnet_lock) {
		if (telnet_sendlock(1) == 0) {
			fprintf(pLogFile, "\nlock flash\n");
		}
		else {
			return -1;
		}
	}

	return 0;
}

int telnet_targets(void) {
	char *curr_str;
	unsigned int recv_length;

	sprintf(send_data, "%s %s\r\n", TELNET_CMD_TARGETS, target_name);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(send_data, 0);

	while(1) {
		curr_str = (char *)&recv_data[0];
		recv_length = cur_recv_length;

		while(recv_length) {
			if (strncmp(curr_str, TELNET_CMD_TARGETS_OK, strlen(TELNET_CMD_TARGETS_OK)) == 0)
				return 0;
			if (strncmp(curr_str, TELNET_CMD_TARGETS_FAIL, strlen(TELNET_CMD_TARGETS_FAIL)) == 0)
				return -1;
			curr_str ++;
			recv_length --;
		}
		telnet_client_recv(TELNET_CMD_TARGETS_OK, 0);
	}
}

int telnet_client_main(void *user_data) {
	unsigned int retry_cnt;
	int burn_failed = 0;
#ifdef __MINGW32__
	telnet_sock = *(SOCKET*)user_data;
#else
	telnet_sock = *(int*)user_data;
#endif
	//Sleep(500);
	/* set input echoing on by default */
	//do_echo = 1;
	/* initialize telnet box */
	telnet = telnet_init(telopts, _event_handler, 0, &telnet_sock);	

	// target priority: target name > target number
	// send select target command must before send algorithm_bin
	if (strcmp(target_name, "") != 0) {
		/* select target name */
		targetnum = -1;
		if (telnet_targets() != 0) {
			telnet_free(telnet);
			close(telnet_sock);
			return -1;
		}
	}

	//if targetnum = -1 means already send targets target_name command
	/* select target_number */
	if (targetnum >= 0) {
		retry_cnt = 5;
		while(retry_cnt) {
			sprintf(send_data, "%s %d\r\n", TELNET_CMD_TARGET_NUM, targetnum);
			telnet_send(telnet, send_data, strlen(send_data));
			if (telnet_client_recv(TELNET_CMD_TARGET_NUM, 100) == 0)
				break;
			retry_cnt --;
		}
	}

	retry_cnt = 5;
	while(retry_cnt) {
		sprintf(send_data, "%s\r\n", TELNET_CMD_RESET_HALT);
		telnet_send(telnet, send_data, strlen(send_data));
		if (telnet_client_recv(TELNET_CMD_RESET_HALT, 10) == 0)
			break;
		retry_cnt --;
	}
	//check platform is v5
	unsigned int platform_v = 0, chk_v5 = 0;
	platform_v = check_platform();
	if (platform_v == 350 || platform_v == 250)
		chk_v5 = 1;

	if (algorithm_bin_filename == NULL) {
		fprintf(pLogFile, "algorithm_bin_filename is NULL.\n");
		fflush(pLogFile);
		telnet_free(telnet);
		close(telnet_sock);
		return -1;
	}
	//algorithm_bin_filename = (char *)NDSSPI_ALGBIN_MAME;
	fprintf(pLogFile, "algorithm_bin_filename: %s\n", algorithm_bin_filename);
	fflush(pLogFile);

	retry_cnt = 5;
	while(retry_cnt) {
		/* init */
		sprintf(send_data, "%s\r\n", TELNET_CMD_INIT);
		telnet_send(telnet, send_data, strlen(send_data));
		if (telnet_client_recv(TELNET_CMD_INIT, 100) == 0)
			break;
		retry_cnt --;
	}

	retry_cnt = 5;
	while(retry_cnt) {
		/* configure algorithm_bin */
		sprintf(send_data, "%s %s\r\n", TELNET_CMD_ALGORITHM, algorithm_bin_filename);
		telnet_send(telnet, send_data, strlen(send_data));
		if (telnet_client_recv("algorithm_bin", 100) == 0)
			break;
		retry_cnt --;
	}

/*
	// for testing
	unsigned int read_addr = 0x200;
	sprintf(send_data, "%s 0x%x\r\n", TELNET_CMD_MDW, read_addr);
	telnet_send(telnet, send_data, strlen(send_data));
	telnet_client_recv(TELNET_CMD_MDW, 10);
*/
	/* check if support target burn */
	if (telnet_query() != 0) {
		fprintf(pLogFile, "\nNOT support target burn!! \n");
		fflush(pLogFile);
		telnet_free(telnet);
		close(telnet_sock);
		return 0;  // skip
	}
	fprintf(pLogFile, "\nsupport target burn!! \n");
	fflush(pLogFile);

	if (chk_v5 == 0) {
		/* bus mode */
		sprintf(send_data, "%s\r\n", TELNET_CMD_BUS);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(TELNET_CMD_BUS, 10);
	}

	burn_failed = telnet_start_burn();

	if (chk_v5 == 0) {
		/* cpu mode */
		sprintf(send_data, "%s\r\n", TELNET_CMD_CPU);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(TELNET_CMD_CPU, 10);
	}

	retry_cnt = 5;
	while(retry_cnt) {
		sprintf(send_data, "%s\r\n", TELNET_CMD_HALT);
		telnet_send(telnet, send_data, strlen(send_data));
		if (telnet_client_recv(TELNET_CMD_HALT, 10) == 0)
			break;
		retry_cnt --;
	}

	//clean memory 0x0(no run algorithm-bin)
	if (platform_v == 350 || platform_v == 250) {
		sprintf(send_data, "%s\r\n", NDSSPI_WRITE_LOOP_V5);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(NDSSPI_WRITE_LOOP_V5, 10);
	} else if (platform_v != 0) {
		sprintf(send_data, "%s\r\n", NDSSPI_WRITE_LOOP_V3);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(NDSSPI_WRITE_LOOP_V3, 10);
	}

	if (burn_failed != 0) {
		/* clean up */
		telnet_free(telnet);
		close(telnet_sock);
		return -1;
	}

	/* ae100, ae300, ae250 and ae350: restore IVB to flash */
	/* ae210p: no need restore_ivb because loading the flash data to ILM on ae210p must do power-on(power-on will reset SMU) */
	if (platform_v == 100) {
		sprintf(send_data, "%s\r\n", NDSSPI_IVB_AE100);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(NDSSPI_IVB_AE100, 10);

		sprintf(send_data, "%s\r\n", NDSSPI_READ_IVB_AE100);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(NDSSPI_IVB_AE100_DONE, 10);
	} else if (platform_v == 300 || platform_v == 350 || platform_v == 250) {
		sprintf(send_data, "%s\r\n", NDSSPI_IVB_AE300);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(NDSSPI_IVB_AE300, 10);

		sprintf(send_data, "%s\r\n", NDSSPI_READ_IVB_AE300);
		telnet_send(telnet, send_data, strlen(send_data));
		telnet_client_recv(NDSSPI_IVB_AE300_DONE, 10);
	}

	//reset target: reset or reset run means reset run 4s. and then hold
	//use reset halt and resume to implement real reset run
	retry_cnt = 5;
	while(retry_cnt) {
		sprintf(send_data, "%s\r\n", TELNET_CMD_RESET_HALT);
		telnet_send(telnet, send_data, strlen(send_data));
		if (telnet_client_recv(TELNET_CMD_RESET_HALT, 10) == 0)
			break;
		retry_cnt --;
	}
	retry_cnt = 5;
	while(retry_cnt) {
		sprintf(send_data, "%s\r\n", TELNET_CMD_RESUME);
		telnet_send(telnet, send_data, strlen(send_data));
		if (telnet_client_recv(TELNET_CMD_RESUME, 100) == 0)
			break;
		retry_cnt --;
	}

	/* clean up */
	telnet_free(telnet);
	close(telnet_sock);
	return 0;
}
