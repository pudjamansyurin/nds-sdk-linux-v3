#!/bin/sh
BASEDIR=$(dirname "$0")
echo "$BASEDIR"
cd $BASEDIR

if [ $# -lt 2 ]; then
	echo "usage : $BASEDIR/build.sh \"LDSAG_PATH\" \"GCC_PATH\" [\"OUTPUT_FOLDER\"]"
	echo "        LDSAG_PATH - ex: \"/cygdrive/c/Andestech/AndeSight_STD_v321/utils\""
	echo "        GCC_PATH - ex: \"/cygdrive/c/Andestech/AndeSight_STD_v320/toolchains/nds64le-elf-mculib-v5/bin\""
	echo "        OUTPUT_FOLDER - default is \"$BASEDIR/build\""
	cd -
	exit
fi
if [ -n "$3" ]; then
  BUILD_DIR=`readlink -f "$3"`
else
  BUILD_DIR=build
fi

# clean build/source folder
rm -rf $BUILD_DIR
mkdir $BUILD_DIR

# sag to ld
echo "transfer sag to ld : "
LDSAG_PATH="$1"
"$LDSAG_PATH/nds_ldsag" -t "$LDSAG_PATH/nds32_template_v5.txt" ./target_burn.sag -o ./target_burn.ld

echo ""

# build bin file
echo "build target_burn.bin"
export PATH="$2":$PATH
if [[ "$2" == *"nds32"* ]]; then
	bit=32
elif [[ "$2" == *"nds64"* ]]; then
	bit=64
else
	echo "unknow bit"
	exit
fi

riscv$bit-elf-gcc -Og -g -Wl, -nostartfiles -Ttarget_burn.ld start.S util.c uart.c platform.c spiflash-MXIC.c smcflash-Micron.c main.c -o "$BUILD_DIR/target_burn.adx"
riscv$bit-elf-objcopy -O binary "$BUILD_DIR/target_burn.adx" "$BUILD_DIR/target_burn.bin"
riscv$bit-elf-objdump -DS "$BUILD_DIR/target_burn.adx" > "$BUILD_DIR/target_burn-objdump.txt"

echo "target_burn.bin is placed \"$BASEDIR/$BUILD_DIR\""

cd -
