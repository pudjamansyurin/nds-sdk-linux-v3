/*
 * Copyright (c) 2012-2017 Andes Technology Corporation
 * All rights reserved.
 *
 */

#include "target_burn.h"
#include "config.h"
#include "util.h"

#if (DEBUG_MSG_LEVEL > 0)
#define BAUD_RATE(n)            (UCLKFREQ / (n) / 16)
char uart_string[512];
char *puart_string = (char *)&uart_string[0];

void uart_init(unsigned int baudrate)
{
	/* Set DLAB to 1 */
	AE250_UART2->LCR |= 0x80;

	/* Set DLL for baudrate */
	AE250_UART2->DLL = (BAUD_RATE(baudrate) >> 0) & 0xff;
	AE250_UART2->DLM = (BAUD_RATE(baudrate) >> 8) & 0xff;

	/* LCR: Length 8, no parity, 1 stop bit. */
	AE250_UART2->LCR = 0x03;

	/* FCR: Enable FIFO, reset TX and RX. */
	AE250_UART2->FCR = 0x07;
}

void uart_putc(int c)
{
#define SERIAL_LSR_THRE         0x20
	while ((AE250_UART2->LSR & SERIAL_LSR_THRE) == 0) ;

	AE250_UART2->THR = c;
}

int outbyte(int c)
{
	uart_putc(c);
	if (c =='\n')
		uart_putc('\r');
	return c;
}
/*
int _write(int file, char *pbuf, unsigned int size)
{
	while (size) {
		outbyte(*pbuf++);
		size --;
	}
	return 0;
}
*/
int uart_putstring(char *pString)
{
	while (*pString) {
		outbyte(*pString++);
	}
	return 0;
}
#endif
