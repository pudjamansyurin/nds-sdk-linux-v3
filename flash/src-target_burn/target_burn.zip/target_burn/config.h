/* choose flash type: SPI_BURN or PAR_BURN */
#define SPI_BURN
//#define PAR_BURN

#define CMD_SIZE              0x8000

/* CHECK_ERR_MSG
 0: OpenOCD and targe_burn_frontend no receive error message
 1: OpenOCD and targe_burn_frontend will check error message and max error message length = 128
*/
#define CHECK_ERR_MSG         1

/* ERROR_MSG_DETAIL
 0: send Error Code to target_burn_frontend console
 1: send Detail Error Message to target_burn_frontend console
*/
#define ERROR_MSG_DETAIL      1

/* DEBUG_MSG_LEVEL
 0: no support uart
 1: send Error Message to uart
 2: send Error and Debug Message to uart
*/
#define DEBUG_MSG_LEVEL       1

#ifdef SPI_BURN
#define FLASH_ID              0x003525c2
#define FLASH_PAGESIZE        0x100
#define FLASH_SECTORSIZE	  0x1000
#define FLASH_TOTALSIZE	      0x100000
#define FLASH_ADDR            0x80000000
#elif defined PAR_BURN
#define FLASH_ID              0x003525c2
#define FLASH_PAGESIZE        0x100
#define FLASH_SECTORSIZE	  0x20000
#define FLASH_TOTALSIZE	      0x2000000
#define FLASH_ADDR            0x88000000
#endif

// command and info need 8 bytes
#if CMD_SIZE < (FLASH_PAGESIZE + 8)
#error CMD_SIZE must >= (FLASH_PAGESIZE + 8)
#endif
