#include "util.h"

#if (ERROR_MSG_DETAIL == 0)
void ERR_CODE_EXIT(unsigned int error_code) {
	cmd_arr[0] = 'E'; \
	cmd_arr[1] = 'C'; \
	cmd_arr[2] = ((error_code % 100) / 10) + 48; \
	cmd_arr[3] = (error_code % 10) + 48; \
	cmd_arr[4] = 0;
}
#endif

/* write word */
/* could use outw write word to target memory */
int outw(unsigned long address, unsigned int w_data)
{
  unsigned int *p_addr = (unsigned int *)address;
	*p_addr = w_data;
	//sprintf(puart_string, "address=0x%x, w_data=0x%x\n", address,  w_data);
  //DEBUG_MSG(puart_string);
  return 0;
}

/* write byte */
/* could use outb write byte to target memory */
int outb(unsigned long address, unsigned char w_data)
{
  unsigned char *p_addr = (unsigned char *)address;
	*p_addr = w_data;
  return 0;
}

/* write half */
/* could use outh write half to target memory */
int outh(unsigned long address, unsigned short w_data)
{
	unsigned short *p_addr = (unsigned short *)address;
	*p_addr = w_data;
  return 0;
}

/* read byte */
/* could use inb read byte from target memory */
unsigned char inb(unsigned long address)
{
  unsigned char *p_addr = (unsigned char *)address;
  return *p_addr;
}

/* read half */
/* could use inh read half from target memory */
unsigned short inh(unsigned long address)
{
  unsigned short *p_addr = (unsigned short *)address;
  return *p_addr;
}

/* read word */
/* could use inw read word from target memory */
unsigned int inw(unsigned long address)
{
	unsigned int *p_addr = (unsigned int *)address;
	unsigned int get_data = *p_addr;
	//sprintf(puart_string, "address=0x%x, p_addr=0x%x\n", address,  get_data);
  //DEBUG_MSG(puart_string);
  return get_data;
}
