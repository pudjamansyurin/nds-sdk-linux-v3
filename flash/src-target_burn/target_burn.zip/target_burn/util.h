#ifndef __UTIL__
#define __UTIL__

#include <stdio.h>

#if (DEBUG_MSG_LEVEL == 0)
#define DEBUG_MSG
#else
extern int uart_putstring(char *pString);
extern char *puart_string;
#define DEBUG_MSG uart_putstring
#endif

extern unsigned char cmd_arr[];
#if (ERROR_MSG_DETAIL == 0)
void ERR_CODE_EXIT(unsigned int error_code);
#elif (ERROR_MSG_DETAIL == 1)
#define ERR_EXIT(f_, ...) snprintf((char *)(cmd_arr), (128), ("E %s:%d "f_), __FILE__,  __LINE__, ##__VA_ARGS__)
#endif

/* type define */
typedef unsigned long long      UINT64;
typedef long long               INT64;
typedef unsigned int            UINT32;
typedef int                     INT32;
typedef unsigned short          UINT16;
typedef short                   INT16;
typedef unsigned char           UINT8;
//typedef char                    INT8;

/* read/write API */
int outw(unsigned long address, unsigned int w_data);
int outb(unsigned long address, unsigned char w_data);
int outh(unsigned long address, unsigned short w_data);
unsigned char inb(unsigned long address);
unsigned short inh(unsigned long address);
unsigned int inw(unsigned long address);
#endif
