#include "config.h"
#include "util.h"
#include "flash-rom.h"

#define STEP_LOCK         1
#define STEP_EXIT         2
#define STEP_UNLOCK       3
#define STEP_TX           4
#define STEP_INIT         6
#define STEP_ERASE        8

extern void nds_ebreak(void);
extern void uart_init(unsigned int baudrate);
#ifdef SPI_BURN
extern flash_dev flash_MXIC;
flash_dev *nds_flash_dev = (flash_dev *)&flash_MXIC;
#elif defined PAR_BURN
extern flash_dev flash_Micron;
flash_dev *nds_flash_dev = (flash_dev *)&flash_Micron;
#endif
unsigned char *current_command_index;
unsigned char cmd_arr[CMD_SIZE] = {6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,1,0,4,0,0,0,0,32,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,2};

int nds_init(void)
{
#if (DEBUG_MSG_LEVEL > 0)
	uart_init(38400);
#endif
	if (nds_flash_dev->flash_chk() != 0)
		return 1;

	// use byte access for only support word-aligned access netlist
	unsigned char *p_packet = (unsigned char *)current_command_index;
	*p_packet ++ = FLASH_ID & 0xff;
	*p_packet ++ = (FLASH_ID & 0xff00) >> 8;
	*p_packet ++ = (FLASH_ID & 0xff0000) >> 16;
	*p_packet ++ = (FLASH_ID & 0xff000000) >> 24;

	*p_packet ++ = FLASH_PAGESIZE & 0xff;
	*p_packet ++ = (FLASH_PAGESIZE & 0xff00) >> 8;
	*p_packet ++ = (FLASH_PAGESIZE & 0xff0000) >> 16;
	*p_packet ++ = (FLASH_PAGESIZE & 0xff000000) >> 24;

	*p_packet ++ = FLASH_SECTORSIZE & 0xff;
	*p_packet ++ = (FLASH_SECTORSIZE & 0xff00) >> 8;
	*p_packet ++ = (FLASH_SECTORSIZE & 0xff0000) >> 16;
	*p_packet ++ = (FLASH_SECTORSIZE & 0xff000000) >> 24;

	*p_packet ++ = FLASH_TOTALSIZE & 0xff;
	*p_packet ++ = (FLASH_TOTALSIZE & 0xff00) >> 8;
	*p_packet ++ = (FLASH_TOTALSIZE & 0xff0000) >> 16;
	*p_packet ++ = (FLASH_TOTALSIZE & 0xff000000) >> 24;

	*p_packet ++ = FLASH_ADDR & 0xff;
	*p_packet ++ = (FLASH_ADDR & 0xff00) >> 8;
	*p_packet ++ = (FLASH_ADDR & 0xff0000) >> 16;
	*p_packet ++ = (FLASH_ADDR & 0xff000000) >> 24;

	current_command_index = (unsigned char*)p_packet;
	return 0;
}

int nds_tx(void)
{
	unsigned char *p_packet = (unsigned char *)current_command_index;
	unsigned int offset=0, tx_size=0;

	offset = *p_packet ++;
	offset |= (*p_packet ++ << 8);
	offset |= (*p_packet ++ << 16);
	offset |= (*p_packet ++ << 24);
	tx_size = *p_packet ++;
	tx_size |= (*p_packet ++ << 8);
	if (tx_size == 0) {
#if (ERROR_MSG_DETAIL == 0)
		ERR_CODE_EXIT(0);
#elif (ERROR_MSG_DETAIL > 0)
		ERR_EXIT("tx_size = 0\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
		sprintf(puart_string, "nds_tx, tx_size = 0\n");
		DEBUG_MSG(puart_string);
#endif
		return 1;
	}

	if (nds_flash_dev->flash_program(offset, p_packet, tx_size) != 0)
		return 1;
	p_packet += tx_size;

	current_command_index = (unsigned char*)p_packet;
	return 0;
}

int nds_erase(void)
{
	unsigned char *p_packet = (unsigned char *)current_command_index;
	unsigned int sector_1st, sector_last;

	sector_1st = *p_packet ++;
	sector_1st |= (*p_packet ++ << 8);
	sector_last = *p_packet ++;
	sector_last |= (*p_packet ++ << 8);
	if (sector_last < sector_1st) {
#if (ERROR_MSG_DETAIL == 0)
		ERR_CODE_EXIT(1);
#elif (ERROR_MSG_DETAIL > 0)
		ERR_EXIT("sector_1st=0x%x > sector_last=0x%x\n", sector_1st, sector_last);
#endif

#if (DEBUG_MSG_LEVEL > 0)
		sprintf(puart_string, "nds_erase, sector_1st=0x%x > sector_last=0x%x \n", sector_1st, sector_last);
		DEBUG_MSG(puart_string);
#endif
		return 1;
	}
	if (nds_flash_dev->flash_erase(sector_1st, sector_last) != 0)
		return 1;

	current_command_index = (unsigned char*)p_packet;
	return 0;
}

int nds_lock(void)
{
	return nds_flash_dev->flash_lock(0, FLASH_TOTALSIZE);
}

int nds_unlock(void)
{
	return nds_flash_dev->flash_unlock(0, FLASH_TOTALSIZE);
}

int main(void)
{
	unsigned char current_cmd = 0;
	unsigned char *p_packet;

	current_command_index = cmd_arr;

	while(1) {
		p_packet = (unsigned char *)current_command_index;
		current_cmd = *p_packet ++;
		current_command_index = (unsigned char*)p_packet;
		if (current_cmd == STEP_LOCK) {
			if (nds_lock() != 0)
				nds_ebreak();
		} else if (current_cmd == STEP_UNLOCK) {
			if (nds_unlock() != 0)
				nds_ebreak();
		} else if (current_cmd == STEP_TX) {
			if (nds_tx() != 0)
				nds_ebreak();
		} else if (current_cmd == STEP_ERASE) {
			if (nds_erase() != 0)
				nds_ebreak();
		} else if (current_cmd == STEP_INIT) {
			if (nds_init() != 0)
				nds_ebreak();
		} else if (current_cmd == STEP_EXIT) {
			nds_ebreak();
		}
	}
	return 0;
}
