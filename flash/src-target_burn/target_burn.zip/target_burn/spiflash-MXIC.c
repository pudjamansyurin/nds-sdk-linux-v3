#include "platform.h"
#include "config.h"
#include "util.h"
#include "flash-rom.h"

#ifdef SPI_BURN
#define INDIVIDUAL_BLK_PROTECT     0
#define QPI_MODE_ENABLE     0
/*--------------------------------------------*/
/* SPI Flash ROM definition                   */
/*--------------------------------------------*/
#define SPIROM_ID_VERSION    0x1420c2  /* MXIC 25L8006  */
/* #define SPIROM_ID_VERSION   0x1520c2   MXIC 25L1606  */
#define SPIROM_ID_MASK       0x00ffffff
#define SPIROM_OP_READ       0x03        /*-- read --*/ 
#define SPIROM_OP_FAST_READ  0x0b        /*-- read in higher speed --*/
#define SPIROM_OP_RDID       0x9f        /*-- manufacturer/device ID read --*/
#define SPIROM_OP_READ_ID    0x90        /*-- manufacturer/device ID read --*/
#define SPIROM_OP_WREN       0x06        /*-- write enable --*/
#define SPIROM_OP_WRDI       0x04        /*-- write disable --*/
#define SPIROM_OP_SE         0x20        /*-- sector erase --*/
#define SPIROM_OP_BE         0x52        /*-- block erase --*/
#define SPIROM_OP_PP         0x02        /*-- page program --*/
#define SPIROM_OP_RDSR       0x05        /*-- read status register --*/
#define SPIROM_OP_WRSR       0x01        /*-- write status register --*/
#define SPIROM_OP_SBLK       0x36        /*-- single block lock --*/
#define SPIROM_OP_SBULK      0x39        /*-- single block unlock --*/
#define SPIROM_OP_RDBLOCK    0x3C
#define SPIROM_OP_RDSCUR     0x2B
#define SPIROM_OP_WPSEL      0x68
#define SPIROM_OP_GBLK       0x7E
#define SPIROM_OP_GBULK      0x98
#define SPIROM_OP_EQIO       0x35
#define SPIROM_OP_RSTQIO     0xF5
#define SPIROM_OP_4PP        0x38

/*-- bit mask for status register --*/
#define SPIROM_SR_WIP_MASK   0x01   /*-- write in progress --*/
#define SPIROM_SR_WEL_MASK   0x02   /*-- write enable --*/
#define SPIROM_SR_BP_MASK    0x3C   /*-- BP protection mode --*/
#define SPIROM_SECTOR_SIZE   FLASH_SECTORSIZE /*-- sector size in bytes, must be 4byte-aligned --*/
#define SPIROM_PAGE_SIZE     FLASH_PAGESIZE  /*-- page size --*/
#define SPIROM_PAGEPROG_ADDR_MASK     0xFFFFFF00
/* security register */
#define SPIROM_SR_P_FAIL     (0x01 << 5)
#define SPIROM_SR_E_FAIL     (0x01 << 6)

/*-- SPI ROM cmd --*/
#define SPIROM_CMD_READ      0x0
#define SPIROM_CMD_RDID      0x1
#define SPIROM_CMD_RDST      0x2
#define SPIROM_CMD_WREN      0x3
#define SPIROM_CMD_WRDI      0x4
#define SPIROM_CMD_ERASE     0x5
#define SPIROM_CMD_PROGRAM   0x6
#define SPIROM_CMD_LOCK      0x7
#define SPIROM_CMD_UNLOCK    0x8
#define SPIROM_CMD_RDBLOCK   0x9
#define SPIROM_CMD_RDSCUR    0xA
#define SPIROM_CMD_WPSEL     0xB
#define SPIROM_CMD_CHIP_UNLOCK   0xC
#define SPIROM_CMD_WRSR      0xD
#define SPIROM_CMD_QUAD_ENA  0xE

#define SPIROM_REAL_SIZE     FLASH_TOTALSIZE

#define FLASH_BLKSIZE    SPIROM_SECTOR_SIZE
#define FLASH_CHIPSIZE   SPIROM_REAL_SIZE
#define FLASH_RETRY_TIMES    0x100000 //0x1000 // 100

#define SPIB_DCTRL_ADDRFMT_QUAD   (0X01 << 28)
#define SPIB_DCTRL_DUALQUAD_QUAD  (0X02 << 22)
unsigned int mxic_qpi_enable = QPI_MODE_ENABLE;
unsigned int mxic_use_qpi_mode = 0;
//unsigned int mxic_quad_enable = 0;

int mxic_check(void);
int mxic_program(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize);
int mxic_erase(unsigned int FlashAddr, unsigned int DataSize);
int mxic_read(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize);
int mxic_lock(unsigned int FlashAddr, unsigned int DataSize);
int mxic_unlock(unsigned int FlashAddr, unsigned int DataSize);
int mxic_set_wrsr(unsigned int uiStat);

flash_dev flash_MXIC = {
    mxic_check,
    mxic_erase,
    mxic_program,
    mxic_read,
    mxic_lock,
    mxic_unlock
};

unsigned int spirom_prepare_cmd(unsigned int cmd, unsigned int addr)
{  
    unsigned int b0 = (cmd & 0xff);
    unsigned int b1 = (((addr >> 16) & 0xff) << 8);
    unsigned int b2 = (((addr >> 8) & 0xff) << 16);
    unsigned int b3 = ((addr & 0xff) << 24);
    unsigned int word = (b0 | b1 | b2 | b3);
    return word;
}

unsigned int spirom_cmd_send (
    unsigned int cmd,
    unsigned int addr,
    unsigned int bytes,
    unsigned char *pdata,
    unsigned int *Retdata)
{
    unsigned int i;
    unsigned int timeout = FLASH_RETRY_TIMES;
    unsigned int spib_dctrl;
    unsigned int op_addr;
    unsigned int data = 0;
    unsigned int spib_busy = 0;
    unsigned int spib_rx_empty;

    /*-- wait if there is active transaction --*/
    spib_busy = spib_wait_spi();
    if (spib_busy != 0)
    {
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("spirom_cmd_send: timeout\n");
#endif
        *Retdata = 0;
        return 1;
    }
    /*-- clear tx/rx fifo --*/
    spib_clr_fifo();

    /*-- prepare opcode and address --*/
    if (cmd == SPIROM_CMD_READ)
    {
        /*-- execute command --*/
        op_addr = spirom_prepare_cmd(SPIROM_OP_READ, addr);
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WR_RD, 3, 0, bytes-1);
        spib_exe_cmmd(op_addr, spib_dctrl);

        spib_rx_data(pdata, bytes);
    }
    else if (cmd == SPIROM_CMD_WREN)
    {
        /*-- execute command --*/
        op_addr = SPIROM_OP_WREN;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 0, 0, 0);
        if (mxic_use_qpi_mode) {
          spib_dctrl |= (SPIB_DCTRL_ADDRFMT_QUAD|SPIB_DCTRL_DUALQUAD_QUAD);
        }
				spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait completion --*/
        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: WREN timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    else if (cmd == SPIROM_CMD_WRDI)
    {
        /*-- execute command --*/
        op_addr = SPIROM_OP_WRDI;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 0, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait completion --*/
        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: WRDI timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    else if (cmd == SPIROM_CMD_ERASE)
    {
        /*-- execute command --*/
        op_addr = spirom_prepare_cmd (SPIROM_OP_SE, addr);
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 3, 0, 0);
        if (mxic_use_qpi_mode) {
          spib_dctrl |= (SPIB_DCTRL_ADDRFMT_QUAD|SPIB_DCTRL_DUALQUAD_QUAD);
        }
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait completion --*/
        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: ERASE timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    else if (cmd == SPIROM_CMD_PROGRAM)
    {
        /*-- execute command --*/
        op_addr = spirom_prepare_cmd (SPIROM_OP_PP, addr);
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 3+bytes, 0, 0);
        if (mxic_use_qpi_mode) {
          spib_dctrl |= (SPIB_DCTRL_ADDRFMT_QUAD|SPIB_DCTRL_DUALQUAD_QUAD);
        } /* else if (mxic_quad_enable) {
          op_addr = spirom_prepare_cmd (SPIROM_OP_4PP, addr);
        } */
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- write data --*/
        spib_tx_data(pdata, bytes);
    }
    else if (cmd == SPIROM_CMD_RDID)
    {
        /*-- execute command --*/
        op_addr = SPIROM_OP_RDID;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WR_RD, 0, 0, 2);
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait data completion --*/
        for (i = 1; i < timeout; i++)
        {
            spib_rx_empty = spib_get_rx_empty ();
            if (spib_rx_empty == 0)
                break;
        }
        if (spib_rx_empty != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: RDID timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
        data = spib_get_data(spib_base);
    }
    else if (cmd == SPIROM_CMD_RDST)
    {
        /*-- execute command --*/
        op_addr = SPIROM_OP_RDSR;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WR_RD, 0, 0, 0);
        if (mxic_use_qpi_mode) {
          spib_dctrl |= (SPIB_DCTRL_ADDRFMT_QUAD|SPIB_DCTRL_DUALQUAD_QUAD);
        }
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait data completion --*/
        for (i = 1; i < timeout; i++)
        {
            spib_rx_empty = spib_get_rx_empty ();
            if (spib_rx_empty == 0)
                break;
        }
        if (spib_rx_empty != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: RDST timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
        data = spib_get_data(spib_base);
#if (DEBUG_MSG_LEVEL >= 2)
        sprintf(puart_string, "SPIROM_CMD_RDST = %x\n", data);
        DEBUG_MSG(puart_string);
#endif
    }
    else if ((cmd == SPIROM_CMD_LOCK) || (cmd == SPIROM_CMD_UNLOCK))
    {
        if(cmd == SPIROM_CMD_LOCK)
          cmd = SPIROM_OP_SBLK;//SPIROM_OP_GBLK;
        else
          cmd = SPIROM_OP_SBULK;//SPIROM_OP_GBULK;

        /*-- execute command --*/
        //op_addr = cmd;
        op_addr = spirom_prepare_cmd (cmd, addr);
        //spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 0, 0, 0);
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 3, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait completion --*/
        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: lock/unlock timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    else if (cmd == SPIROM_CMD_RDBLOCK)
    {
        /*-- execute command --*/
        //op_addr = SPIROM_OP_RDBLOCK;
        op_addr = spirom_prepare_cmd (SPIROM_OP_RDBLOCK, addr);
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WR_RD, 3, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait data completion --*/
        for (i = 1; i < timeout; i++)
        {
            spib_rx_empty = spib_get_rx_empty ();
            if (spib_rx_empty == 0)
                break;
        }
        if (spib_rx_empty != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: RDBLOCK timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
        data = spib_get_data(spib_base);
    }
    else if (cmd == SPIROM_CMD_RDSCUR)
    {
        /*-- execute command --*/
        op_addr = SPIROM_OP_RDSCUR;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WR_RD, 0, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait data completion --*/
        for (i = 1; i < timeout; i++)
        {
            spib_rx_empty = spib_get_rx_empty ();
            if (spib_rx_empty == 0)
                break;
        }
        if (spib_rx_empty != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: RDSCUR timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
        data = spib_get_data(spib_base);
    }
    else if (cmd == SPIROM_CMD_CHIP_UNLOCK)
    {
        op_addr = SPIROM_OP_GBULK;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 0, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: GBULK timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    #if INDIVIDUAL_BLK_PROTECT
    else if (cmd == SPIROM_CMD_WPSEL)
    {
        op_addr = SPIROM_OP_WPSEL;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 0, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: WPSEL timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    #endif
    else if (cmd == SPIROM_CMD_WRSR)
    {
        /*-- execute command --*/
        op_addr = (SPIROM_OP_WRSR | (addr<<8));
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 1, 0, 0);
        spib_exe_cmmd(op_addr, spib_dctrl);

        /*-- wait completion --*/
        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: ERASE timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    else if ((cmd == SPIROM_CMD_QUAD_ENA) && (mxic_qpi_enable))
    {
        /*-- execute command --*/
        if (addr == 1)
            op_addr = SPIROM_OP_EQIO;
        else
            op_addr = SPIROM_OP_RSTQIO;
        spib_dctrl = spib_prepare_dctrl (0x0, 0x0, SPIB_TM_WRonly, 0, 0, 0);
        if (mxic_use_qpi_mode) {
            spib_dctrl |= (SPIB_DCTRL_ADDRFMT_QUAD|SPIB_DCTRL_DUALQUAD_QUAD);
        }
        spib_exe_cmmd(op_addr, spib_dctrl);
        /*-- wait completion --*/
        spib_busy = spib_wait_spi();
        if (spib_busy != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("spirom_cmd_send: EN_QUAD timeout\n");
#endif
            *Retdata = 0;
            return 1;
        }
    }
    else
    {
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("spirom_cmd_send: wrong cmd\n");
#endif
        *Retdata = 0;
        return 1;
    }

    *Retdata = data;
    return 0;
}

#if INDIVIDUAL_BLK_PROTECT
unsigned int spirom_WPSEL_command(void)
{
    unsigned int RetData;
    
    spirom_cmd_send (SPIROM_CMD_RDSCUR, 0x0, 0, NULL, &RetData);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "spirom_WPSEL_command-0, %x \n", RetData);
    DEBUG_MSG(puart_string);
#endif
    if(RetData & 0x80)
        return 0;
    
    /*-- write enable --*/
    spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "spirom_WPSEL_command-1, %x \n", RetData);
    DEBUG_MSG(puart_string);
#endif
    spirom_cmd_send (SPIROM_CMD_WPSEL, 0x0, 0, NULL, &RetData);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "spirom_WPSEL_command-2, %x \n", RetData);
    DEBUG_MSG(puart_string);
#endif
    /*-- get enable status --*/
    while(1)
    {
        spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
        if ((RetData & SPIROM_SR_WIP_MASK) == 0)
            break;
#if (DEBUG_MSG_LEVEL >= 2)
        sprintf(puart_string, "spirom_WPSEL_command-3, %x \n", RetData);
        DEBUG_MSG(puart_string);
#endif
    }
    spirom_cmd_send (SPIROM_CMD_RDSCUR, 0x0, 0, NULL, &RetData);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "spirom_WPSEL_command-finish, %x \n", RetData);
    DEBUG_MSG(puart_string);
#endif
    if(RetData & 0x80)
        return 0;
    else
        return 1;
}
#endif

int mxic_unlock_chip(void)
{
    unsigned int j, RetData, timeout=FLASH_RETRY_TIMES;
    /*-- write enable --*/
    spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
    
    /*-- get enable status --*/
    for (j = 1; j < timeout; j++)
    {
        spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
        if ((RetData & SPIROM_SR_WIP_MASK) == 0)
            break;
    }
    if ((RetData & SPIROM_SR_WEL_MASK) == 0) {
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("mxic_unlock_chip: (ULock) write enable is not set\n");
#endif
    }
    /*-- Chip-UnLock --*/
    spirom_cmd_send (SPIROM_CMD_CHIP_UNLOCK, 0x0, 0, NULL, &RetData);

    /*-- get ULock status --*/
    for (j = 1; j < timeout; j++)
    {
        spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
        if ((RetData & SPIROM_SR_WIP_MASK) == 0)
            break;
    }
    if ((RetData & SPIROM_SR_WIP_MASK) != 0)
    {
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("mxic_unlock_chip: ULock is still in progress\n");
#endif
        return 1;
    }
    spirom_cmd_send (SPIROM_CMD_RDBLOCK, 0, 0, NULL, &RetData);

    if ((RetData & 0xFF) == 0xFF)
    {
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("mxic_unlock_chip: ULock-chip fail\n");
#endif
        return 1;
    }
    return 0;
}
// TODO: modify this function to target-specific function - check flash
int mxic_check(void)
{
    unsigned int result, RetData;
    // mark fast-mode
    unsigned int SCLK_DIV = 0;
    //if (guiFastMode == 0)
    //    SCLK_DIV=0xC0;
    //else
    //    SCLK_DIV=0x01;
    
    RetData = (spib_get_regtiming(spib_base) & (~0xFF));
    spib_set_regtiming(spib_base, RetData | SCLK_DIV);
    SCLK_DIV = spib_get_regtiming(spib_base);

    // Set SCLK period = ((0+1)*2)*(Period of the SPI clock source)
    //RetData = (spib_get_regtiming(spib_base) & (~0xFF));
    //RetData |= 0x07;
    //spib_set_regtiming(spib_base, RetData);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "mxic_check: REGTIMING=%x\n", spib_get_regtiming(spib_base));
    DEBUG_MSG(puart_string);
#endif
    result = spirom_cmd_send (SPIROM_CMD_RDID, 0x0, 0, NULL, &RetData);
    if (result != 0)
    {
#if (ERROR_MSG_DETAIL == 0)
        ERR_CODE_EXIT(2);
#elif (ERROR_MSG_DETAIL > 0)
        ERR_EXIT("read spi rom id fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("ERROR: read spi rom id fail\n");
#endif
        return 1;
    }
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "MXIC: ROM ID = 0x%08x \n", RetData);
    DEBUG_MSG(puart_string);
#endif
#if (INDIVIDUAL_BLK_PROTECT==0)
    // check if "WPSEL"==1, then do chip-unlock
    spirom_cmd_send (SPIROM_CMD_RDSCUR, 0x0, 0, NULL, &RetData);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "WPSEL = %x \n", RetData);
    DEBUG_MSG(puart_string);
#endif
    if(RetData & 0x80)
    {
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("mxic_unlock_chip");
#endif
        mxic_unlock_chip();
    }
#endif
    return 0;
}
// TODO: modify this function to target-specific function - erase flash
int mxic_erase(unsigned int sector_1st, unsigned int sector_last)
{
    unsigned int EraseAddrStart, i, j;
    unsigned int result, RetData, timeout=FLASH_RETRY_TIMES;

    if (mxic_qpi_enable) {
        result = spirom_cmd_send (SPIROM_CMD_QUAD_ENA, 1, 0, NULL, &RetData);
        mxic_use_qpi_mode = 1;
    }
    EraseAddrStart = sector_1st * SPIROM_SECTOR_SIZE;
    for (i = sector_1st; i <= sector_last; i++)
    {
        /*---------------------*/
        /*-- ERASE procedure   */
        /*---------------------*/
        for (j = 1; j < timeout; j++)
        {
            /*-- write enable --*/
            result = spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
            if (result != 0)
            {
#if (ERROR_MSG_DETAIL == 0)
                ERR_CODE_EXIT(3);
#elif (ERROR_MSG_DETAIL > 0)
                ERR_EXIT("enable write fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
                DEBUG_MSG("mxic_erase: (erase) enable write fail\n");
#endif
                return 1;
            }
            /*-- get enable status --*/
            spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
            if (RetData & SPIROM_SR_BP_MASK)
            {
#if (ERROR_MSG_DETAIL == 0)
                ERR_CODE_EXIT(4);
#elif (ERROR_MSG_DETAIL > 0)
                ERR_EXIT("Flash block locked\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
                DEBUG_MSG("mxic_erase: Flash block locked\n");
#endif
                return 1;
            }
            else if (RetData & SPIROM_SR_WEL_MASK)
                break;
        }
        if ((RetData & SPIROM_SR_WEL_MASK) == 0) {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_erase: write enable is not set\n");
#endif
        }

        #if INDIVIDUAL_BLK_PROTECT
        spirom_cmd_send (SPIROM_CMD_RDBLOCK, EraseAddrStart, 0, NULL, &RetData);
        if ((RetData & 0xFF) == 0xFF)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(4);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("Flash block locked\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("\nmxic_erase - Flash block locked.\n");
#endif
            return 1;
        }
        #endif
#if (DEBUG_MSG_LEVEL >= 2)
        sprintf(puart_string, "erasing block %03d (0x%06x ~ 0x%06x)\n", i, EraseAddrStart, EraseAddrStart + SPIROM_SECTOR_SIZE);
        DEBUG_MSG(puart_string);
#endif
        /*-- erase --*/
        result = spirom_cmd_send (SPIROM_CMD_ERASE, EraseAddrStart, 0, NULL, &RetData);
        if (result != 0)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(5);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("rom erase fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_erase: rom erase fail\n");
#endif
            return 1;
        }
        /*-- ckeck completion --*/
        for (j = 1; j < timeout; j++)
        {
          spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
          if ((RetData & SPIROM_SR_WIP_MASK) == 0)
            break;
        }
        if (RetData & SPIROM_SR_WIP_MASK)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(6);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("is still in progress\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_erase: is still in progress\n");
#endif
            return 1;
        }

        spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
        if ((RetData & SPIROM_SR_WEL_MASK) != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_erase: write enable is not clear\n");
#endif
            //return 1;
        }
        spirom_cmd_send (SPIROM_CMD_RDSCUR, 0x0, 0, NULL, &RetData);
        if (RetData & SPIROM_SR_E_FAIL)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(7);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("erase fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_erase: erase fail\n");
#endif
            return 1;
        }
        //DEBUG_MSG("mxic_erase: status ok\n");
        EraseAddrStart += SPIROM_SECTOR_SIZE;
    }
    if (mxic_qpi_enable) {
        result = spirom_cmd_send (SPIROM_CMD_QUAD_ENA, 0, 0, NULL, &RetData);
        mxic_use_qpi_mode = 0;
    }
    return 0;
}
// TODO: modify this function to target-specific function - program flash
int mxic_program(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize)
{
    unsigned int result, RetData = 0, PageCnt, addr, i;
    unsigned int j, timeout=FLASH_RETRY_TIMES;

    if (mxic_qpi_enable) {
        result = spirom_cmd_send (SPIROM_CMD_QUAD_ENA, 1, 0, NULL, &RetData);
        mxic_use_qpi_mode = 1;
    } /* else if (mxic_quad_enable) {
        mxic_set_wrsr(0x40);  // bit-6: Quad Enable
    } */

    if(FlashAddr & (~SPIROM_PAGEPROG_ADDR_MASK))
    {
#if (ERROR_MSG_DETAIL == 0)
        ERR_CODE_EXIT(8);
#elif (ERROR_MSG_DETAIL > 0)
        ERR_EXIT("addr is NOT page-align\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("mxic_program: addr is NOT page-align!!");
#endif
        return 1;
    }
    PageCnt = (DataSize + (SPIROM_PAGE_SIZE - 1)) / SPIROM_PAGE_SIZE;
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "PageCnt=0x%x", PageCnt);
    DEBUG_MSG(puart_string);
#endif
    /*---------------------------*/
    /*-- PAGE PROGRAM procedure  */
    /*---------------------------*/
    for (i = 0; i < PageCnt; i++)
    {
        for (j = 1; j < timeout; j++)
        {
          /*-- write enable --*/
          result = spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
          if (result != 0)
          {
#if (ERROR_MSG_DETAIL == 0)
              ERR_CODE_EXIT(3);
#elif (ERROR_MSG_DETAIL > 0)
              ERR_EXIT("enable write fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
              DEBUG_MSG("mxic_program: (program) page enable write fail\n");
#endif
              return 1;
          }
          /*-- get enable status --*/
          spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
          if (RetData & SPIROM_SR_BP_MASK)
          {
#if (ERROR_MSG_DETAIL == 0)
              ERR_CODE_EXIT(4);
#elif (ERROR_MSG_DETAIL > 0)
              ERR_EXIT("Flash block locked\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
              DEBUG_MSG("mxic_program: Flash block locked.\n");
#endif
              return 1;
          }
          else if (RetData & SPIROM_SR_WEL_MASK)
            break;
        }
        if ((RetData & SPIROM_SR_WEL_MASK) == 0)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(9);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("write enable is not set\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_program: (program) page, write enable is not set\n");
#endif
            return 1;
        }
        addr = FlashAddr + (i * SPIROM_PAGE_SIZE);
        result = spirom_cmd_send (SPIROM_CMD_PROGRAM, addr, SPIROM_PAGE_SIZE, (unsigned char*)start, &RetData);
        if (result != 0)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(10);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("program fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_program: (program) page fail\n");
#endif
            return 1;
        }
        /*-- ckeck completion --*/
        for (j = 1; j < timeout; j++)
        {
          spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
          if ((RetData & SPIROM_SR_WIP_MASK) == 0)
            break;
        }
        if (RetData & SPIROM_SR_WIP_MASK)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(11);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("program is still in progress\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_program: is still in progress\n");
#endif
            return 1;
        }

        spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
        if ((RetData & SPIROM_SR_WEL_MASK) != 0)
        {
#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_program: (program) page, write enable is not clear\n");
#endif
            //return 1;
        }
        spirom_cmd_send (SPIROM_CMD_RDSCUR, 0x0, 0, NULL, &RetData);
        if (RetData & SPIROM_SR_P_FAIL)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(12);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("program fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_program: program fail\n");
#endif
            return 1;
        }
#if (DEBUG_MSG_LEVEL >= 2)
        sprintf(puart_string, "completion=0x%x", i);
        DEBUG_MSG(puart_string);
#endif
#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG(".");
#endif
        start += SPIROM_PAGE_SIZE;
    }  /* for (i = 0; i < PageCnt; i++) */

    if (mxic_qpi_enable) {
        result = spirom_cmd_send (SPIROM_CMD_QUAD_ENA, 0, 0, NULL, &RetData);
        mxic_use_qpi_mode = 0;
    } /* else if (mxic_quad_enable) {
        mxic_set_wrsr(0x0);  // bit-6: Quad Enable
    } */
    //DEBUG_MSG("-finish");
    return 0;
}
// TODO: modify this function to target-specific function - read flash
int mxic_read(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize)
{
    unsigned int result, RetData, CurrSize;
    /*-- SPIB_DCTRL_RCNT_MASK(0x1ff) --*/
    while(DataSize)
    {
        if(DataSize >= 0x200)
            CurrSize = 0x200;
        else
            CurrSize = DataSize;
        result = spirom_cmd_send (SPIROM_CMD_READ, FlashAddr, CurrSize, (unsigned char*)start, &RetData);
        if (result != 0)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(13);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("read fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("Flash_Read: fail\n");
#endif
            return 1;
        }
        FlashAddr += CurrSize;
        start += CurrSize;
        DataSize -= CurrSize;
    }
    return 0;
}
// TODO: modify this function to target-specific function - lock flash
int mxic_lock(unsigned int FlashAddr, unsigned int DataSize)
{
#if INDIVIDUAL_BLK_PROTECT
    unsigned int LockAddrStart, LockSize, LockSectorCnt, LockSectorIndex;
    unsigned int RetData, timeout=FLASH_RETRY_TIMES, i, j;

    LockAddrStart = (FlashAddr / SPIROM_SECTOR_SIZE) * SPIROM_SECTOR_SIZE;
    LockSize = (FlashAddr - LockAddrStart) + DataSize;
    LockSectorCnt = (LockSize + (SPIROM_SECTOR_SIZE - 1)) / SPIROM_SECTOR_SIZE;
    LockSectorIndex = (LockAddrStart / SPIROM_SECTOR_SIZE);
    
    spirom_WPSEL_command();
    for (i = 0; i < LockSectorCnt; i++)
    {
        /*---------------------*/
        /*-- Lock procedure   */
        /*---------------------*/
        /*-- write enable --*/
        spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
        
        /*-- get enable status --*/
        for (j = 1; j < timeout; j++)
        {
            spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
            if ((RetData & SPIROM_SR_WIP_MASK) == 0)
                break;
        }
        if ((RetData & SPIROM_SR_WEL_MASK) == 0) {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(9);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("write enable is not set\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_lock: (Lock) write enable is not set\n");
#endif
        }

        /*-- lock --*/
        spirom_cmd_send (SPIROM_CMD_LOCK, LockAddrStart, 0, NULL, &RetData);
    
        /*-- get lock status --*/
        for (j = 1; j < timeout; j++)
        {
            spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
            if ((RetData & SPIROM_SR_WIP_MASK) == 0)
                break;
        }
        if ((RetData & SPIROM_SR_WIP_MASK) != 0)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(14);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("Lock is still in progress\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_lock: Lock is still in progress\n");
#endif
            return 1;
        }
        spirom_cmd_send (SPIROM_CMD_RDBLOCK, LockAddrStart, 0, NULL, &RetData);
        if ((RetData & 0xFF) != 0xFF)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(15);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("Lock fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_lock: Lock fail\n");
#endif
            return 1;
        }
        LockAddrStart += SPIROM_SECTOR_SIZE;
        LockSectorIndex++;
    }
#else
    unsigned int RetData=0;
    
    spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
    mxic_set_wrsr(RetData | 0x3C);
    spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
#endif
    return 0;
}
// TODO: modify this function to target-specific function - unlock flash
int mxic_unlock(unsigned int FlashAddr, unsigned int DataSize)
{
#if INDIVIDUAL_BLK_PROTECT
    unsigned int ULockAddrStart, ULockSize, ULockSectorCnt, ULockSectorIndex;
    unsigned int RetData, timeout=FLASH_RETRY_TIMES, i, j;

    ULockAddrStart = (FlashAddr / SPIROM_SECTOR_SIZE) * SPIROM_SECTOR_SIZE;
    ULockSize = (FlashAddr - ULockAddrStart) + DataSize;
    ULockSectorCnt = (ULockSize + (SPIROM_SECTOR_SIZE - 1)) / SPIROM_SECTOR_SIZE;
    ULockSectorIndex = (ULockAddrStart / SPIROM_SECTOR_SIZE);

    spirom_WPSEL_command();
    for (i = 0; i < ULockSectorCnt; i++)
    {
        /*---------------------*/
        /*-- ULock procedure   */
        /*---------------------*/
        /*-- write enable --*/
        spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
        
        /*-- get enable status --*/
        for (j = 1; j < timeout; j++)
        {
            spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
            if ((RetData & SPIROM_SR_WIP_MASK) == 0)
                break;
        }
        if ((RetData & SPIROM_SR_WEL_MASK) == 0) {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(9);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("write enable is not set\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_unlock: (ULock) write enable is not set\n");
#endif
        }
        /*-- ULock --*/
        spirom_cmd_send (SPIROM_CMD_UNLOCK, ULockAddrStart, 0, NULL, &RetData);
    
        /*-- get ULock status --*/
        for (j = 1; j < timeout; j++)
        {
            spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
            if ((RetData & SPIROM_SR_WIP_MASK) == 0)
                break;
        }
        if ((RetData & SPIROM_SR_WIP_MASK) != 0)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(16);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("ULock is still in progress\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_unlock: ULock is still in progress\n");
#endif
            return 1;
        }
        spirom_cmd_send (SPIROM_CMD_RDBLOCK, ULockAddrStart, 0, NULL, &RetData);
        if ((RetData & 0xFF) == 0xFF)
        {
#if (ERROR_MSG_DETAIL == 0)
            ERR_CODE_EXIT(17);
#elif (ERROR_MSG_DETAIL > 0)
            ERR_EXIT("ULock fail\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
            DEBUG_MSG("mxic_unlock: ULock fail\n");
#endif
            return 1;
        }
        //spirom_cmd_send (SPIROM_CMD_RDSCUR, 0x0, 0, NULL, &RetData);
        //sprintf(puart_string, "mxic_unlock: RDSCUR %x \n", RetData);
        //DEBUG_MSG(puart_string);
        ULockAddrStart += SPIROM_SECTOR_SIZE;
        ULockSectorIndex++;
    }
#else
  unsigned int RetData=0;
  spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
  mxic_set_wrsr(RetData & ~0x3C);
  spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
#endif
  return 0;
}

int mxic_set_wrsr(unsigned int uiStat)
{
  unsigned int i, j, RetData=0, timeout=FLASH_RETRY_TIMES;

  for (i = 1; i < timeout; i++)  {
      /*-- write enable --*/
      spirom_cmd_send (SPIROM_CMD_WREN, 0x0, 0, NULL, &RetData);
      /*-- get enable status --*/
      for (j = 1; j < timeout; j++)  {
          spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
          if ((RetData & SPIROM_SR_WIP_MASK) == 0)
              break;
      }
      if (RetData & SPIROM_SR_WEL_MASK)
          break;
  }
  /*-- set WRSR --*/
  spirom_cmd_send (SPIROM_CMD_WRSR, uiStat, 0, NULL, &RetData);

  /*-- get status --*/
  for (j = 1; j < timeout; j++)  {
      spirom_cmd_send (SPIROM_CMD_RDST, 0x0, 0, NULL, &RetData);
      if ((RetData & SPIROM_SR_WIP_MASK) == 0)
          break;
  }
#if (DEBUG_MSG_LEVEL >= 2)
  sprintf(puart_string, "mxic_set_wrsr: uiStat=%x RetData=%x\n", uiStat, RetData);
  DEBUG_MSG(puart_string);
#endif
  return 0;
}
#endif
