#ifndef __PLAT_AE210P__
#define __PLAT_AE210P__

#define SPIB_TM_WRsim               0x0
#define SPIB_TM_WRonly              0x1
#define SPIB_TM_RDonly              0x2
#define SPIB_TM_WR_RD               0x3
#define SPIB_TM_RD_WR               0x4
#define SPIB_TM_WR_DY_RD            0x5
#define SPIB_TM_RD_DY_WR            0x6

#define SPIB_VERSION                0x02002000

/* SPIB register definition  */
#define SPIB_REG_VER        (0x00)
#define SPIB_REG_IFSET      (0x10)
#define SPIB_REG_PIO        (0x14)
#define SPIB_REG_DCTRL      (0x20)
#define SPIB_REG_CMD        (0x24)
#define SPIB_REG_ADDR       (0x28)
#define SPIB_REG_DATA       (0x2c)
#define SPIB_REG_CTRL       (0x30)
#define SPIB_REG_FIFOST     (0x34)
#define SPIB_REG_INTEN      (0x38)
#define SPIB_REG_INTST      (0x3c)
#define SPIB_REG_REGTIMING  (0x40)
/*-- Data Control Reg --*/
#define SPIB_DCTRL_CMDEN_MASK       0x40000000
#define SPIB_DCTRL_ADDREN_MASK      0x20000000
#define SPIB_DCTRL_TRAMODE_MASK     0x0f000000
#define SPIB_DCTRL_WCNT_MASK        0x001ff000
#define SPIB_DCTRL_DYCNT_MASK       0x00000600
#define SPIB_DCTRL_RCNT_MASK        0x000001ff
#define SPIB_DCTRL_CMDEN_OFFSET     30
#define SPIB_DCTRL_ADDREN_OFFSET    29
#define SPIB_DCTRL_TRAMODE_OFFSET   24
#define SPIB_DCTRL_WCNT_OFFSET      12
#define SPIB_DCTRL_DYCNT_OFFSET     9
#define SPIB_DCTRL_RCNT_OFFSET      0
#define SPIB_DCTRL_ADDRFMT_OFFSET   28
#define SPIB_DCTRL_DUALQUAD_OFFSET  22
/*-- Control Reg --*/
#define SPIB_CTRL_TXFRST_MASK       0x00000004
#define SPIB_CTRL_RXFRST_MASK       0x00000002
#define SPIB_CTRL_SPIRST_MASK       0x00000001
/*-- FIFO Status Reg --*/
#define SPIB_FIFOST_TXFFL_MASK      0x00800000
#define SPIB_FIFOST_TXFEM_MASK      0x00400000
#define SPIB_FIFOST_TXFVE_MASK      0x001f0000
#define SPIB_FIFOST_RXFFL_MASK      0x00008000
#define SPIB_FIFOST_RXFEM_MASK      0x00004000
#define SPIB_FIFOST_RXFVE_MASK      0x00001f00
#define SPIB_FIFOST_SPIBSY_MASK     0x00000001
#define SPIB_FIFOST_TXFFL_OFFSET    23
#define SPIB_FIFOST_TXFEM_OFFSET    22
#define SPIB_FIFOST_TXFVE_OFFSET    16
#define SPIB_FIFOST_RXFFL_OFFSET    15
#define SPIB_FIFOST_RXFEM_OFFSET    14
#define SPIB_FIFOST_RXFVE_OFFSET    8
#define SPIB_FIFOST_SPIBSY_OFFSET   0
#define SPIB_FIFOST_SPIBSYnRXFEM    (SPIB_FIFOST_RXFEM_MASK|SPIB_FIFOST_SPIBSY_MASK)

#define spib_get_ifset(base)          inw(base+SPIB_REG_IFSET)
#define spib_set_ifset(base, setVal)  outw(base+SPIB_REG_IFSET, setVal)
#define spib_get_pio(base)            inw(base+SPIB_REG_PIO)
#define spib_set_pio(base, setVal)    outw(base+SPIB_REG_PIO, setVal)
#define spib_get_ctrl(base)           inw(base+SPIB_REG_CTRL)
#define spib_set_ctrl(base, setVal)   outw(base+SPIB_REG_CTRL, setVal)
#define spib_get_fifost(base)         inw(base+SPIB_REG_FIFOST)
#define spib_get_inten(base)          inw(base+SPIB_REG_INTEN)
#define spib_set_inten(base, setVal)  outw(base+SPIB_REG_INTEN, setVal)

#define spib_get_intst(base)          inw(base+SPIB_REG_INTST)
#define spib_set_intst(base, setVal)  outw(base+SPIB_REG_INTST, setVal)
#define spib_get_dctrl(base)          inw(base+SPIB_REG_DCTRL)
#define spib_set_dctrl(base, setVal)  outw(base+SPIB_REG_DCTRL, setVal)
#define spib_get_cmd(base)            inw(base+SPIB_REG_CMD)
#define spib_set_cmd(base, setVal)    outw(base+SPIB_REG_CMD, setVal)
#define spib_get_addr(base)           inw(base+SPIB_REG_ADDR)
#define spib_set_addr(base, setVal)   outw(base+SPIB_REG_ADDR, setVal)
#define spib_get_data(base)           inw(base+SPIB_REG_DATA)
#define spib_set_data(base, setVal)   outw(base+SPIB_REG_DATA, setVal)
#define spib_get_regtiming(base)      inw(base+SPIB_REG_REGTIMING)
#define spib_set_regtiming(base, setVal) outw(base+SPIB_REG_REGTIMING, setVal)

#define spib_get_version(base)        (inw(base+SPIB_REG_VER))
#define spib_get_busy(base)           (inw(base+SPIB_REG_FIFOST) & SPIB_FIFOST_SPIBSY_MASK)
#define spib_get_rx_empty(base)       (inw(base+SPIB_REG_FIFOST) & SPIB_FIFOST_RXFEM_MASK)
#define spib_get_rx_entries(base)     ((inw(base+SPIB_REG_FIFOST) & SPIB_FIFOST_RXFVE_MASK) >> SPIB_FIFOST_RXFVE_OFFSET)

extern unsigned int spib_prepare_dctrl(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int);
extern unsigned int spib_wait_spi (void);
extern void spib_clr_fifo (void);
extern void spib_exe_cmmd (unsigned int op_addr, unsigned int spib_dctrl);
extern void spib_rx_data (unsigned char *pRxdata, int RxBytes);
extern void spib_tx_data (unsigned char *pTxdata, int TxBytes);

extern unsigned int spib_base;
#endif

