//#include <sys/time.h>
#include "config.h"
#include "util.h"
#include "flash-rom.h"

#ifdef PAR_BURN
#define MX_Type     (0x01)
#define SST_Type    (0x02)
#define Intel_Type  (0x03)
#define AMD_Type    (0x04)
#define Micron_Type (0x05)

#define FLASH_SINGLE (0x00)
#define FLASH_DOUBLE (0x01)
#define FLASH_FOUR   (0x02)

/*#ifdef __MINGW32__
#include <winsock2.h>
#define SLEEP(t) _sleep(t)
#elif defined _WIN32
#include <windows.h>
#define SLEEP(t) Sleep(t)
#else
#include <unistd.h>
#define SLEEP(t) usleep(t * 1000)
#endif*/

#define FLASH_BASE       FLASH_ADDR
#define FLASH_BLKSIZE    FLASH_SECTORSIZE
#define FLASH_CHIPSIZE   FLASH_TOTALSIZE

int micron_wait_program_done(unsigned base, unsigned last_addr, unsigned short last_data);
void micron_flash_reset(unsigned base);
void micron_flash_return_to_read(unsigned base);
int micron_check(void);
int micron_program(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize);
int micron_erase(unsigned int sector_1st, unsigned int sector_last);
int micron_read(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize);
int micron_lock(unsigned int FlashAddr, unsigned int DataSize);
int micron_unlock(unsigned int FlashAddr, unsigned int DataSize);

flash_dev flash_Micron = {
        micron_check,
        micron_erase,
        micron_program,
        micron_read,
        micron_lock,
        micron_unlock
};

#define MICRON_MODE_AUTO_SELECT                     (0x90)
#define MICRON_MODE_ENTER_NONVOLATILE_PROTECTION    (0xC0)
#define MICRON_MODE_BLOCK_ERASE                     (0x80)
#define MICRON_MODE_BUFFERED_PROGRAM_ABORT_RESET    (0xF0)
#define MICRON_MODE_UNLOCK_BYPASS                   (0x20)
#define MICRON_MODE_WRITE_TO_BUFFER_PROGRAM         (0x25)

void micron_goto_mode(unsigned int base, unsigned int goto_mode)
{
	unsigned int set_more = 0;

	outh(base + 0x555*2, 0xaa);
	outh(base + 0x2aa*2, 0x55);
	if (goto_mode == MICRON_MODE_WRITE_TO_BUFFER_PROGRAM) {
		// WRITE TO BUFFER PROGRAM (25h)
		outh(base, 0x25);
		return;
	} else if (goto_mode == MICRON_MODE_BLOCK_ERASE) {
		// BLOCK ERASE (80/30h)
		set_more = 0x30;
	}
	outh(base + 0x555*2, goto_mode);

	if (set_more != 0) {
		outh(base + 0x555*2, 0xaa);
		outh(base + 0x2aa*2, 0x55);
		outh(base, set_more);
	}
}

void micron_exit_protection_command(unsigned int base)
{
	// EXIT PROTECTION COMMAND SET (90/00h)
	outh(base, 0x90);
	outh(base, 0x00);
}
/*
void micron_BlockErase(unsigned int addr_start, unsigned int BusWidth)
{
        unsigned int base = FLASH_BASE;

        base += addr_start;
        //x16 555-AA 2AA-55 555-80 555-AA 2AA-55 BAd-30
        micron_goto_mode(base, MICRON_MODE_BLOCK_ERASE);

        while ((inh(base) ^ 0xffff) & 0xffff) {
                //SLEEP (32);
                for(int i=0; i<100; i++) {}
        }
}
*/
int micron_ProgramMultiWord(unsigned int base, volatile unsigned int address, unsigned char *buffer, unsigned int size)
{
        volatile unsigned int bytes = size % 4;
        volatile unsigned int word;
        unsigned int last_address;
        unsigned int j;
        unsigned int cmd = base + address;
        unsigned int *cmd_buf = (unsigned int *)buffer;
        unsigned int cmd_size = size;

        /* not word align */
        if (size % 4 != 0)
                size = size - bytes;
        if (size != 0) {
                //x16 555-AA 2AA-55 BAd-25 BAd-N PA PD
                word = (size / 2) - 1;
                micron_goto_mode(base, MICRON_MODE_WRITE_TO_BUFFER_PROGRAM);
                outh(base, word);
                while(cmd_size > 0)
                {
                    outw(cmd, *cmd_buf);
                    cmd = cmd + 4;
                    cmd_buf = cmd_buf + 1;
                    cmd_size = cmd_size - 4;
                }

                /* last program address */
                last_address = address + size - 0x2;

                /* WRITE TO BUFFER PROGRAM CONFIRM */
                outh(base + last_address, 0x29);
                //SLEEP(1);
                for(int i=0; i<10; i++)
                {}
                if (micron_wait_program_done(base, last_address, *((short *)(buffer + size - 2))) < 0)
                        return -1;
        }
        if (bytes) {
                word = 0;
                for (j = 0; j <= bytes; j++)
                        word = word | (buffer[size+j] << (j*8));

                if (micron_ProgramMultiWord(base, address + size, (unsigned char *)&word, 4) < 0)
                        return -1;
        }
        return 0;
}

/*
 * functions for Micron flash
 */
int micron_wait_program_done(unsigned int base, unsigned int last_addr, unsigned short last_data)
{
        short data;
        unsigned time = 0;
        unsigned retry_count = 4096 * 2;  // NOTE: typical max block erase timeout = 4s
        data = inh(base + last_addr);

        while ((data ^ last_data) & 0x80) {
                data = inh(base + last_addr);
                /* check failure or abort bit */
                if (data & 0x22) {
                        data = inh(base + last_addr);
                        if ((data ^ last_data) & 0x80) {
                                /* BUFFERED PROGRAM ABORT and RESET command */
                                micron_goto_mode(base, MICRON_MODE_BUFFERED_PROGRAM_ABORT_RESET);
                        }
                }
                time++;
                if (time > 100) {
                        //SLEEP(1);
                        for(int i=0; i<10; i++)
                        {}
#if (DEBUG_MSG_LEVEL >= 2)
                        sprintf(puart_string, "program failure or abort! status = %08x\n", data);
                        DEBUG_MSG(puart_string);
#endif

                }
                if (time > retry_count) {
#if (ERROR_MSG_DETAIL == 0)
                        ERR_CODE_EXIT(20);
#elif (ERROR_MSG_DETAIL > 0)
                        ERR_EXIT("program fail, operation abort\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
                        DEBUG_MSG("program fail, operation abort\n");
#endif
                        return -1;
                }
        }
        return 0;
}

void micron_flash_reset(unsigned int base)
{
        outh(base, 0xf0);
}

void micron_flash_return_to_read(unsigned int base)
{
        /* execute UNLOCK BYPASS RESET command to return to read/reset mode from unlock bypass mode */
        micron_exit_protection_command(base);
        /* execute RESET command to return to read/reset mode and resets the errors */
        micron_flash_reset(base);
}
// TODO: modify this function to target-specific function - check flash
int micron_check(void)
{
        unsigned int base = FLASH_BASE;
        unsigned short id1, id2;

        micron_flash_return_to_read(base);

        /* go to AUTO SELECT mode */
        micron_goto_mode(base, MICRON_MODE_AUTO_SELECT);

        /* read ID */
        id1 = inh(base+0x0);
        id2 = inh(base+0x1*2);

        /* return to READ mode */
        micron_flash_reset(base);

        if (id1 == 0x0089 && id2 == 0x227e) {
#if (DEBUG_MSG_LEVEL >= 2)
                sprintf(puart_string, "Micron: ID1 = 0x%04hx, ID2 = 0x%04hx\n", id1, id2);
                DEBUG_MSG(puart_string);
#endif
                return 0;
        } else {
#if (ERROR_MSG_DETAIL == 0)
                ERR_CODE_EXIT(19);
#elif (ERROR_MSG_DETAIL > 0)
                ERR_EXIT("ID error");
#endif

#if (DEBUG_MSG_LEVEL > 0)
                DEBUG_MSG("\nmicron_check - ID error.\n");
#endif
                return -1;
		}
}
// TODO: modify this function to target-specific function - program flash
int micron_program(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize)
{
        unsigned int base = FLASH_BASE;
        unsigned int address = FlashAddr;
        unsigned int end = address + DataSize;
        unsigned int buf_size = end - address;
        unsigned int boundary = 1024;
        int result = 0;

        while (address < end) {
                /*
                 * Micron flash cannot write across 1k boundary, if
                 * this is the case, it should be split into two part.
                 */
               if (buf_size > boundary) {
                       buf_size = boundary;
                       if (address / boundary != (address + buf_size - 4) / boundary) {
                               buf_size = ((address / boundary) + 1) * boundary - address;
#if (DEBUG_MSG_LEVEL >= 2)
                               sprintf(puart_string, "buf_size = %d\n", buf_size);
                               DEBUG_MSG(puart_string);
#endif
                       }
              }
              if (micron_ProgramMultiWord(base, address, start, buf_size) < 0) {
                        result = -1;
                        break;
              }

              start += buf_size;
              address += buf_size;
                //if (address % 8*1024 == 0) {	// IDE use 8K/dot
                //        DEBUG_MSG(".");   
                //}
        }
        return result;
}
// TODO: modify this function to target-specific function - erase flash
int micron_erase(unsigned int sector_1st, unsigned int sector_last)
{
        unsigned int EraseAddrStart, i;
        unsigned int base, Status;

        EraseAddrStart = sector_1st * FLASH_BLKSIZE;
        base = FLASH_BASE + EraseAddrStart;
        for (i = sector_1st; i <= sector_last; i++) {
                //ENTER NONVOLATILE PROTECTION COMMAND SET (C0h)
                // 555-AA 2AA-55 555-C0
                micron_goto_mode(base, MICRON_MODE_ENTER_NONVOLATILE_PROTECTION);

                //READ NONVOLATILE PROTECTION BIT STATUS
                // BAd READ(0)
                Status = inh(base+0x0);
                //printf("micron_erase Status= %x\n", Status);
                if (Status == 0) {
#if (ERROR_MSG_DETAIL == 0)
                        ERR_CODE_EXIT(4);
#elif (ERROR_MSG_DETAIL > 0)
                        ERR_EXIT("Flash block locked\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
                        DEBUG_MSG("\nmicron_erase - Flash block locked.\n");
#endif
                        return -1;
                }
                //EXIT PROTECTION COMMAND SET (90/00h)
                // X-90 X-00
                micron_exit_protection_command(base);
#if (DEBUG_MSG_LEVEL >= 2)
                sprintf(puart_string, "erasing block %03d (0x%07x ~ 0x%07x)\n", i, EraseAddrStart, EraseAddrStart + FLASH_BLKSIZE);
                DEBUG_MSG(puart_string);
#endif
                //micron_BlockErase(EraseAddrStart, FLASH_FOUR);
                //x16 555-AA 2AA-55 555-80 555-AA 2AA-55 BAd-30
                micron_goto_mode(base, MICRON_MODE_BLOCK_ERASE);

                while ((inh(base) ^ 0xffff) & 0xffff) {
                  //SLEEP (32);
                  for(int i=0; i<100; i++) {;}
                }
                base += FLASH_BLKSIZE;
                EraseAddrStart += FLASH_BLKSIZE;
        }
        return 0;
}
// TODO: modify this function to target-specific function - read flash
int micron_read(unsigned int FlashAddr, unsigned char *start, unsigned int DataSize)
{
        unsigned int base = FLASH_BASE + FlashAddr;
        unsigned int *cmd_buf = (unsigned int *)start;
        DataSize = ((DataSize + 3) / 4) * 4;

        while(DataSize > 0) {
            *cmd_buf = inw(base);
            base = base + 4;
            cmd_buf = cmd_buf + 1;
            DataSize = DataSize - 4;
        }
        return 0;
}

// TODO: modify this function to target-specific function - lock/unlock flash
void micron_lock_unlock(unsigned int FlashAddr, unsigned int DataSize, unsigned int if_lock)
{
        unsigned int base = FLASH_BASE + FlashAddr;
        unsigned int addr_end = (base+DataSize);
        unsigned int Status=0;

        while (base < addr_end) {
                //ENTER NONVOLATILE PROTECTION COMMAND SET (C0h)
                // 555-AA 2AA-55 555-C0
                micron_goto_mode(base, MICRON_MODE_ENTER_NONVOLATILE_PROTECTION);

                //READ NONVOLATILE PROTECTION BIT STATUS
                // BAd READ(0)
                Status = inh(base+0x0);
                //printf("micron_lock Status= %x\n", Status);
                if (if_lock == 1) {
	                //PROGRAM NONVOLATILE PROTECTION BIT (A0h)
	                // X-A0 BAd-00
	                outh(base, 0xA0);
	                outh(base, 0x00);
	                Status = inh(base+0x0);
	              } else {
	                //CLEAR ALL NONVOLATILE PROTECTION BITS (80/30h)
                  // X-80 00-30
                  outh(base, 0x80);
                  outh(base, 0x30);

                  while (1) {
                    Status = inh(base+0x0);
                    Status = inh(base+0x0);
                    if (Status == 0x01)
                      break;
                  }
                }
#if (DEBUG_MSG_LEVEL >= 2)
                sprintf(puart_string, "micron_lock Status= %x\n", Status);
                DEBUG_MSG(puart_string);
#endif
                //EXIT PROTECTION COMMAND SET (90/00h)
                // X-90 X-00
                micron_exit_protection_command(base);

                base += FLASH_BLKSIZE;
        }
        return;
}

// TODO: modify this function to target-specific function - lock flash
int micron_lock(unsigned int FlashAddr, unsigned int DataSize)
{
	micron_lock_unlock(FlashAddr, DataSize, 1);
	return 0;
}

// TODO: modify this function to target-specific function - unlock flash
int micron_unlock(unsigned int FlashAddr, unsigned int DataSize)
{
	micron_lock_unlock(FlashAddr, DataSize, 0);
	return 0;
}
#endif
