#include "config.h"
#include "platform.h"
#include "util.h"

#define REG_SMC_BASE        0xE0400000
#define REG_AHBC_BASE       0xE0000000
#define REG_SMU_BASE        0xF0100000
#define CPE_SPIB_BASE       0xF0B00000

#define SMU_SYSID_AE350     0x41453500
#define SMU_SYSID_AE250     0x41452500

#define MEMMAP_AE350    0
#define MEMMAP_AE250    1
#define MEMMAP_MAX      2

#if (DEBUG_MSG_LEVEL >= 2)
const char* memmapping_target_name[MEMMAP_MAX] = {
    "AE350",
    "AE250",
};
#endif
void platform_init(void);
void platform_init_ae350(void);
void platform_get_version_id(void);
#ifdef SPI_BURN
unsigned int spib_ctrl = 0;
unsigned int spib_base = 0x0;
#endif

void platform_init(void)
{
    unsigned int id1=0;//, EDM_cfg=0, EDM_version=0;
    unsigned int i, smu_base;
    unsigned int smu_id_reg = 0;
    unsigned int mem_mapping_mode = MEMMAP_AE350;

    unsigned int memmapping_smu_base[MEMMAP_MAX] = {
      REG_SMU_BASE,           // AE350
      REG_SMU_BASE,           // AE250
    };
    unsigned int memmapping_system_id[MEMMAP_MAX] = {
      SMU_SYSID_AE350,        // AE350
      SMU_SYSID_AE250,        // AE250
    };
#ifdef SPI_BURN
    unsigned int memmapping_spib_base[MEMMAP_MAX] = {
      CPE_SPIB_BASE,          // AE350
      CPE_SPIB_BASE,          // AE250
    };
#endif
    for (i = 0; i < MEMMAP_MAX; i++) {
        smu_base = memmapping_smu_base[i];
        smu_id_reg = inw(smu_base + 0x00);
        id1 = smu_id_reg;
        // Check SMU System ID
        if (id1 == memmapping_system_id[i]) {
            mem_mapping_mode = i;
            break;
        }
    }
    if( i == MEMMAP_MAX ) {
#if (ERROR_MSG_DETAIL == 0)
        ERR_CODE_EXIT(18);
#elif (ERROR_MSG_DETAIL > 0)
        ERR_EXIT("no match SMU_SYSID\n");
#endif

#if (DEBUG_MSG_LEVEL > 0)
        DEBUG_MSG("no match SMU_SYSID");
#endif
        return;
    }
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "SMU_VER_ID = 0x%08x \n", smu_id_reg);
    DEBUG_MSG(puart_string);
    sprintf(puart_string, "Target = %s\n", memmapping_target_name[mem_mapping_mode]);
    DEBUG_MSG(puart_string);
#endif

#ifdef SPI_BURN
    spib_base = memmapping_spib_base[mem_mapping_mode];
    spib_ctrl = spib_get_ctrl(spib_base);
#if (DEBUG_MSG_LEVEL >= 2)
    sprintf(puart_string, "spib_base = 0x%08x, spib_ctrl = 0x%08x \n", spib_base, spib_ctrl);
    DEBUG_MSG(puart_string);
#endif
#elif defined PAR_BURN
    if (mem_mapping_mode == MEMMAP_AE350) {
        platform_init_ae350();
    }
#endif
}

void platform_init_ae350(void)
{
    const unsigned int SMC_BASE  = REG_SMC_BASE;
    unsigned int smc_bank0_reg;

    /* Write memory bank 0 configuration register */
    /* Disable write-protect, set BNK_SIZE to 64MB, set BNK_MBW to 32 */
    smc_bank0_reg = inw(SMC_BASE);
    /* limit BNK_SIZE = 32MB */
    smc_bank0_reg = (smc_bank0_reg & ~0xf0) | 0x50;
    /* disable write protection */
    smc_bank0_reg = (smc_bank0_reg & ~0x800);
    /* debug ae350 */
    //smc_bank0_reg = (smc_bank0_reg | 0x8000000);
    outw(SMC_BASE, smc_bank0_reg);
    /*outw(SMC_BASE+4, 0x00153153);*/
}

#ifdef SPI_BURN
unsigned int spib_prepare_dctrl(
  unsigned int cmden,
  unsigned int addren,
  unsigned int tm,
  unsigned int wcnt,
  unsigned int dycnt,
  unsigned int rcnt)
{
  unsigned int v[8];
  unsigned int i;
  unsigned int dctrl = 0x0;

  v[0] = ((cmden << SPIB_DCTRL_CMDEN_OFFSET) & SPIB_DCTRL_CMDEN_MASK);
  v[1] = ((addren << SPIB_DCTRL_ADDREN_OFFSET) & SPIB_DCTRL_ADDREN_MASK);
  v[2] = ((tm << SPIB_DCTRL_TRAMODE_OFFSET) & SPIB_DCTRL_TRAMODE_MASK);
  v[3] = ((wcnt << SPIB_DCTRL_WCNT_OFFSET) & SPIB_DCTRL_WCNT_MASK);
  v[4] = ((dycnt << SPIB_DCTRL_DYCNT_OFFSET) & SPIB_DCTRL_DYCNT_MASK);
  v[5] = ((rcnt << SPIB_DCTRL_RCNT_OFFSET) & SPIB_DCTRL_RCNT_MASK);

  for (i = 0; i < 6; i++)
      dctrl |= v[i];
  return dctrl;
}

unsigned int spib_wait_spi (void)
{
  unsigned int i;
  unsigned int timeout = 0x100000;//100;

  for (i = 1; i < timeout; i++)
  { 
      if (spib_get_busy (spib_base) == 0)
          return 0;
  }
#if (DEBUG_MSG_LEVEL > 0)
  DEBUG_MSG("spib_wait_spi: timeout\n");
#endif
  return 1;
}

void spib_clr_fifo (void)
{
  //unsigned int spib_ctrl = inw(SPIB_REG_CTRL);
  spib_ctrl |= (SPIB_CTRL_TXFRST_MASK | SPIB_CTRL_RXFRST_MASK);
  spib_set_ctrl(spib_base, spib_ctrl); 
}

void spib_exe_cmmd (unsigned int op_addr, unsigned int spib_dctrl)
{
  /*-- execute command --*/
  spib_set_data(spib_base, op_addr);        /*-- push flash command into tx fifo --*/
  spib_set_dctrl(spib_base, spib_dctrl);    /*-- set dctrl --*/
  spib_set_cmd(spib_base, 0x0);             /*-- set dummy command to trigger transation start --*/
}

void spib_rx_data (unsigned char *pRxdata, int RxBytes)
{
  unsigned int i, RxWords = 0;
  unsigned char *p_dst_buffer = (unsigned char *)pRxdata;
  unsigned int rx_data = 0;

  /*-- wait completion --*/
  while (spib_get_busy (spib_base) != 0) {
    if (spib_get_rx_empty (spib_base) == 0) {
      RxWords = spib_get_rx_entries (spib_base);
      for (i = 0; i < RxWords; i++) {
        rx_data = inw(SPIB_REG_DATA);
        *p_dst_buffer++ = (rx_data & 0xff);
        *p_dst_buffer++ = (rx_data & 0xff00) >> 8;
        *p_dst_buffer++ = (rx_data & 0xff0000) >> 16;
        *p_dst_buffer++ = (rx_data & 0xff000000) >> 24;
      }
    }
  }
  RxWords = spib_get_rx_entries (spib_base);
  for (i = 0; i < RxWords; i++) {
    rx_data = inw(SPIB_REG_DATA);
    *p_dst_buffer++ = (rx_data & 0xff);
    *p_dst_buffer++ = (rx_data & 0xff00) >> 8;
    *p_dst_buffer++ = (rx_data & 0xff0000) >> 16;
    *p_dst_buffer++ = (rx_data & 0xff000000) >> 24;
  }
}

void spib_tx_data (unsigned char *pTxdata, int TxBytes)
{
  unsigned int i, j;
  unsigned int TxWords = (TxBytes / 4);
  unsigned char *p_src_buffer = (unsigned char *)pTxdata;
  unsigned int timeout = 100;
  unsigned int spib_tx_full;
  unsigned int tx_data = 0;

  for (i = 0; i < TxWords; i++) {
    for (j = 0; j < timeout; j++) {
      spib_tx_full = (spib_get_fifost(spib_base) & SPIB_FIFOST_TXFFL_MASK);

      if (spib_tx_full == 0) {
        break;
      }
    }
    if (spib_tx_full == 1) {
#if (DEBUG_MSG_LEVEL > 0)
      DEBUG_MSG("spib_set_fifo: write fifo timeout\n");
#endif
      return;
    }
    tx_data = *p_src_buffer++;
    tx_data |= (*p_src_buffer++ << 8);
    tx_data |= (*p_src_buffer++ << 16);
    tx_data |= (*p_src_buffer++ << 24);
    spib_set_data(spib_base, tx_data);
  }
}
#endif
